# Change Log

### v0.2.2

_2022.5.17_

- feat:  新增逻辑组件`WebEnv`
- feat:  优化预览UI界面、新增markdown文件预览

### v0.2.1

_2022.4.26_

- feat:  新增组件`CodePreview`、`ImagePreview`、`PdfPreview`、`VideoPreview`、`ParseUrl`、`ValidityChecker`、`HyUpload`

### v0.1.15

_2022.4.11_

- fix: magic code, 暂时解决NOS上传大文件崩溃问题 

### v0.1.14

_2022.3.18_

- feat: 'Cropper'组件对外提供`submit`与`cancel`方法

### v0.1.13

_2022.2.16_

- feat: 'Cropper'组件在内外框重合时操作点进行分离

### v0.1.12

_2022.1.24_

- feat: 'upload'组件支持通过`onBeforeRequest`回调自定义请求参数
- feat: 新增组件'Cropper'

### v0.1.11

_2022.1.20_

- fix:  `Nos`上传时对`ObjectKey`进行转码，修复特殊文件名上传错误的问题

### v0.1.10

_2022.1.20_

- fix:  修复上传中可能出现的页面抖动
- fix:  修复`svg`上传时获取错误宽高的问题

### v0.1.9

_2022.1.12_

- fix:  修复`svg`使用`base64`上传失败的问题
- chore:  `NOS`上传使用统一url
- chore:  `NOS`上传由`分块并行`降级为`分块串行`

### v0.1.8

_2022.1.5_

- feat: `Nos/Oss`上传成功后返回`objectName`

### v0.1.7

_2022.1.5_

- Hello, 2022
- feat: `Nos/Oss`上传增加参数`app`
- feat: `Nos/Oss`增加`thumbnail`用于图片缩放

### v0.1.6

- 无效版本

### v0.1.5

_2021.12.28_

- feat: 新增`OssUploader`

### v0.1.4

_2021.12.10_

- feat: `NOSUploader`支持`securityCheck`属性

### v0.1.3

_2021.12.10_

- feat: `NOSUploader`支持在`uploader`中定义回调函数覆盖全局配置

### v0.1.2

_2021.12.07_

- feat: `NOSUploader`支持`base64`上传

### v0.1.1

_2021.12.06_

- feat: `NOSUploader.uploads`支持批量参数
- feat: `NOSUploader`的`onSuccess`回调中返回图片尺寸(仅当上传图片时)
- feat: `NOSUploader`支持`onProgress`回调

### v0.1.0

_2021.11.19_

- feat: 增加组件`NOSUploader`