# @di/netease-hy-design

一个基于 Vue 的富交互、轻量级、高性能的前端组件库

## 描述
@di/netease-hy-design集成了数创团队业务中经常使用到的前端组件，可以方便高效地帮助我们完成业务的开发工作。

## 安装
```
npm i @di/netease-hy-design -S --registry http://rnpm.hz.netease.com/
```

### 注意点
为了不打包所有的组件，你需要进行如下配置，coming soon
```
...
```

## 组件列表
Type. | Name | Description | Author
---|---|---|---
 逻辑模块 | [BaseUploader](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/BaseUploader.md) | 抽象上传组件 | hewenjun@corp.netease.com
 逻辑模块 | [NosUploader](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/NosUploader.md) | Nos上传组件 | hewenjun@corp.netease.com
 逻辑模块 | [OssUploader](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/ssUploader.md) | Oss上传组件 | hewenjun@corp.netease.com
 UI模块 | [Cropper](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/Cropper.md) | 裁剪组件 | hewenjun@corp.netease.com
 UI组件 | [CodePreview](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/CodePreview.md) | 代码预览弹窗 | hewenjun@corp.netease.com
 UI组件 | [ImagePreview](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/ImagePreview.md) | 图片预览弹窗 | hewenjun@corp.netease.com
 UI组件 | [PdfPreview](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/PdfPreview.md) | PDF预览弹窗 | hewenjun@corp.netease.com
 UI组件 | [VideoPreview](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/VideoPreview.md) | 视频预览弹窗 | hewenjun@corp.netease.com
 逻辑模块 | [ParseUrl](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/ParseUrl.md) | url解析 | xulizhi@corp.netease.com
 逻辑模块 | [ValidityChecker](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/ValidityChecker.md) | 合法性校验模块 | xulizhi@corp.netease.com
 UI组件 | [HyUpload](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/HyUpload.md) | 上传UI组件 | xulizhi@corp.netease.com
 逻辑模块 | [WebEnv](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/doc/WebEnv.md) | WebEnv | yangbo08@corp.netease.com

  <!-- module list -->


## 联系我们
作者 | Email
--- | ---
潘吉 | panji@corp.netease.com
何文俊 | hewenjun@corp.netease.com
郝洋洋 | wb.haoyangyang@corp.netease.com
徐利智 | xulizhi@corp.netease.com

Issue反馈： [点此](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/issues)

## 更多
[点此](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/master/CHANGELOG.md)查看最近更新，升级版本使用最新功能。
[如何加入，成为一个体面的开发者？](https://office.netease.com/doc/?identity=dba206b316b74446a75dd8bfbc52f50d)

# License
[MIT License(comming soon)](https://raw.githubusercontent.com/coming_soon)

