### CodePreview
代码预览弹窗

## props
| 参数  | 说明  | 类型  | 默认值  |
| ------------ | ------------ | ------------ | ------------ |
| theme  | 主题(light | dark)  | String  | dark |
| codeSrc  | 待弹出的code dom  | HTMLElement  | -  |


## 用法
```html
<template>
  <div>
    <h1>CodePreview</h1>
    <code>      &lt;Toolbar
        style="border-bottom: 1px solid #ccc"
        :editor="editor"
        :defaultConfig="toolbarConfig"
      /&gt;
    </code>
    <code-preview
      v-model="visible"
      theme="dark"
      :code-src="codeSrc"
    />
    <button @click="showPreview">show</button>
  </div>
</template>

<script>
import { CodePreview } from '@di/netease-hy-design'

export default {
  name: 'DemoCodePreview',
  components: {
    CodePreview,
  },
  data () {
    return {
      visible: false,
      codeSrc: null,
    }
  },
  mounted () {
    this.codeSrc = document.getElementsByTagName('code')[0]
  },
  methods: {
    showPreview () {
      this.visible = true
    }
  }
}
</script>

```