### Cropper
UI组件-裁剪, 支持通过内外框的操作，实现对图片的裁剪支持

## 用法
参考[demo](https://g.hz.netease.com/commercialize/foundations/netease-hy-design/-/blob/feature/master/src/views/cropper.vue)