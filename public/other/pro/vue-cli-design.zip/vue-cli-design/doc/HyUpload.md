### HyUpload
集成NosUploader的上传组件:
  1. 自定义上传样式
  2. 自定义提示
  3. 支持批量上传多个文件（或视频）
  4. 自定义上传校验
  5. 可删除已上传的文件
  6. 可控的上传列表

## 用法
```vue
<template>
  <HyUpload
    ref="fileUpload"
    :accept=".mp4,.wmv,.mov,.flv,.avi,.webm,.mkv"
    :uploadParams="{app: 'cms', code: 'creative-cms'}"
    :beforeUploadHook="beforeUploadHook"
    @success="successEvent"
  >
    <template slot="content"> <!-- 自定义上传样式 -->
    </template>
    <template slot="tips"> <!-- 自定义文字提示 -->
    </template>
  </HyUpload>
</template>

<script>
import { HyUpload } from '@di/netease-hy-design'
export default {
  components: {
    HyUpload
  },
  methods: {
    successEvent(msg){ // 上传成功文件回调
      // msg: {
      //   name: info.file.name,
      //   size: info.file.size,
      //   url: res[0].url
      // }
      // 将成功返回的文件地保存到后端
   },
   submit () {
     this.$refs.fileUpload.getList().then(list => { // 自行请求获取上传的文件列表直到拿到结果
       // list: 上传成功的文件列表
     })
   }
}
</script>
```
## **参数说明**
| 参数 | 说明 | 类型 | 默认值 |
| ---      |  ------  |----------|----------|
| accept   | 接受上传的文件类型  |  string  |  所有类型|
| limit    | 上传文件单个大小 | number|  10|
| isMultiple|    是否支持多选文件，开启后按ctrl可选多个文件  | blooean  |  false|
| uploadParams|   上传参数(参考nos) | object |  无|
| length|   上传文件个数限制| number|  1|
| fileUrl|   回显文件列表| array|  无|
| isShowList|   是否显示文件列表| blooean  |  true|
| isShow|   是否隐藏上传按钮| blooean  |  false|
| beforeUploadHook|   自定义上传前校验方法| function| () => { return true }|
| isShowProgress|   是否显示默认进度| blooean | false|
| uploadType|   上传方式(nos: commom/私有化: private)| string| 'common'|
