### ImagePreview
图片预览弹窗, 具备自适应缩放能力

## props
| 参数  | 说明  | 类型  | 默认值  |
| ------------ | ------------ | ------------ | ------------ |
| bodyStyle  | 自定义弹窗样式, 如{padding: xxx}  | Map<String, String>  | { padding: '5px 5px' } |


## 用法
```vue
<template>
  <div>
    <h1>ImagePreview</h1>
    <image-preview :theme="theme"  v-model="visible" :src="imageSrc" />
    <button @click="showPreview">light theme</button>
    <button @click="showPreview('dark')">dark theme</button>
  </div>
</template>

<script>
import { ImagePreview } from '@di/netease-hy-design'

export default {
  name: 'DemoImagePreview',
  components: {
    ImagePreview,
  },
  data () {
    return {
      theme: '',
      visible: false,
      imageSrc: 'https://img6.bdstatic.com/img/image/pcindex/sunjunpchuazhoutu.JPG',
    }
  },
  methods: {
    showPreview (theme) {
      this.theme = theme
      this.visible = true
    }
  }
}
</script>
```