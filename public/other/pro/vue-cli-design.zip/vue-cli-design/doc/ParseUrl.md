### ParseUrl
描述: 给定一个url字符串，可以使用该方法解析其中的各种属性

## 用法
```vue
<script>
import { ParseUrl } from '@di/netease-hy-design'

const result = parseURL(url) //成功返回result
// [{protocol: 协议
//  host:主机名称
//  port:端口号
//  query: 查询字符串
//  params: 查询参数
//  file: 文件名
//  hash: 哈希参数
//  path: 路径
//  relative: 相对路径
//  segments:路径片段
// }]
</script>
