### PdfPreview
PDF预览弹窗, 具备pdf横向铺满能力

## props
| 参数  | 说明  | 类型  | 默认值  |
| ------------ | ------------ | ------------ | ------------ |
| src  | pdf url  | String  | - |


## 用法
```html
<template>
  <div>
    <h1>PdfPreview</h1>
    <pdf-preview v-model="visible" src="https://mini.nos-jd.163yun.com/202203091925659972821568827393_creative_ps_saas_%E7%8F%AD%E8%BD%A6%E8%B7%AF%E7%BA%BF210909.pdf?fileName=%E7%8F%AD%E8%BD%A6%E8%B7%AF%E7%BA%BF210909.pdf&Signature=CBaj1AvpUZkgHi%2BbsFwZzugYDV45ZFcsQ09Nq8pHUpI%3D&Expires=4802428800&NOSAccessKeyId=a2b368da8d27405fbe0e771bf7ab2cf9" />
    <button @click="showPreview">show</button>
  </div>
</template>

<script>
import { PdfPreview } from '@di/netease-hy-design'

export default {
  name: 'DemoPdfPreview',
  components: {
    PdfPreview,
  },
  data () {
    return {
      visible: false,
    }
  },
  methods: {
    showPreview (theme) {
      this.visible = true
    }
  }
}
</script>

```