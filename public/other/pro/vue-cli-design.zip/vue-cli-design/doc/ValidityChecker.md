### ValidityChecker
描述: 使用正则表达式进行合法性校验，功能包括：
1. 校验是否为邮箱地址
2. 校验是否为手机号

## 用法
```vue
<script>
import { ValidityChecker } from '@di/netease-hy-design'

ValidityChecker({ type: 'email', value: 'xxx@com' }) // true||false
ValidityChecker({ type: 'phone', value: '12345678000' })  // true||false
</script>
```