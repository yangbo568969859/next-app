### PdfPreview
视频预览组件, 提供弹窗预览能力，支持自适应视频尺寸

## props
| 参数  | 说明  | 类型  | 默认值  |
| ------------ | ------------ | ------------ | ------------ |
| controls  | 同`<video>`标签同名属性  | Boolean  | true |
| muted  | 同`<video>`标签同名属性  | Boolean  | false |
| autoplay  | 同`<video>`标签同名属性  | Boolean  | true |
| src  | video url  | String  | - |


## 用法
```javascript
<template>
  <div>
    <h1>VideoPreview</h1>
    <video-preview v-model="visible" src="https://mini.nos-jd.163yun.com/202203081123659489102433202177_creative_ps_saas_Project_WebGL_to_Video.mp4?fileName=Project_WebGL_to_Video.mp4&Signature=sXanA8rykNcheg79OxMwqj4N%2FAe%2B428aPyrX7VbltrE%3D&Expires=4802342400&NOSAccessKeyId=a2b368da8d27405fbe0e771bf7ab2cf9" />
    <button @click="showPreview">show</button>
  </div>
</template>

<script>
import { VideoPreview } from '@di/netease-hy-design'

export default {
  name: 'DemoVideoPreview',
  components: {
    VideoPreview,
  },
  data () {
    return {
      visible: false
    }
  },
  methods: {
    showPreview () {
      this.visible = true
    }
  }
}
</script>
```