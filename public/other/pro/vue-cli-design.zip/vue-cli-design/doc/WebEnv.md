# 逻辑组件web-env
## 描述
用于从用户 `userAgent` 中检测浏览器类型、引擎、设备类型、是否微信环境
## 使用
```html
<script>
import { WebEnv } from '@di/netease-hy-design'
export default {
  data () {
    return {
      browser: null,
      engine: null,
      os: null,
      device: null,
      resultSets: null
    }
  },
  mounted () {
    this.getWebEnv()
  },
  methods: {
    getWebEnv () {
      // 使用方式
      // const ua = webEnv(window.navigator.userAgent)
      const ua = WebEnv('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB5; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)')
      this.browser = ua.getBrowser()
      this.engine = ua.getEngine()
      this.os = ua.getOS()
      this.device = ua.getDevice()
      
      this.resultSets = ua.getResult()
   }
}
</script>
```

## 参数说明
| 参数 | 说明 | 类型 | 默认值 |
| ---      |  ------  |----------|----------|
| userAgent   | 浏览器userAgent  |  string  |  无|

## Methods
* `getBrowser()`
    * returns `{ name: 'IE', version: '8.0' }`

* `getDevice()`
    * returns `PC|Mobile|Tablet|iPad`

* `getOS()`
    * returns `{ name: 'Windows', version: 'XP' }`

* `isWeixin`
    * returns `true`

* `getResult()`
    * returns `{ browser: {}, device: 'PC', os: {}, network: '4g', isWeixin: true }`