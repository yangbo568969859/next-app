/**
 * @description: 基础预览组件参数
 */
export const MAX_WIDTH = 900
export const MIN_WIDTH = 200
