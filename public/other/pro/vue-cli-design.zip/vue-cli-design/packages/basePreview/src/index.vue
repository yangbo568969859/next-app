<script>
/**
 * @description: 基础预览组件, 提供弹窗预览能力，不支持直接使用
 *
 */
import Vue from 'vue'
import {
  Modal
} from 'ant-design-vue'
import { MAX_WIDTH, MIN_WIDTH } from './config'

Modal.install(Vue)

export default {
  name: 'BasePreview',
  components: {
    [Modal.name]: Modal
  },
  props: {
    value: {
      type: Boolean,
      default: false
    },
    src: {
      type: String,
      default: null
    }
  },
  data () {
    return {
      show: false,
      modalWidth: 480,
      modalHeight: 320
    }
  },
  watch: {
    show (val) {
      this.$emit('input', this.show)
    },
    value (val) {
      this.show = val
    }
  },
  methods: {
    setStyle ({ width: w, height: h }) {
      const bite = w / h
      if (h > w) {
        this.modalHeight = Math.max(Math.min(MAX_WIDTH, w), MIN_WIDTH)
        this.modalWidth = this.modalHeight * bite
      } else {
        this.modalWidth = Math.max(Math.min(MAX_WIDTH, w), MIN_WIDTH)
        this.modalHeight = this.modalWidth / bite
      }
    }
  }
}
</script>
