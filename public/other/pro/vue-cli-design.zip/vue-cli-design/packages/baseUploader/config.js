/**
 * @description: 模块配置
 */

export const TOKEN_URL = '/api/{app}/creativecommon/upload/token'
export const GENERATE_URL = '/api/{app}/creativecommon/upload/generateUrl'
export const UNKNOWN_ERROR = '服务正忙, 请稍后再试'
