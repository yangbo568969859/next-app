<template>
  <div
    :class="['base-button', $style['container'], className]"
    :type="type"
    :disabled="disabled"
    :style="{
      height: typeof height === 'number' ? `${height}px` : height,
    }"
    @click="click"
  >
    <slot />
  </div>
</template>

<script>
export default {
  name: 'BaseButton',
  props: {
    type: {
      type: String, // primary,sub,default,主要(蓝色背景),主要-副(蓝色文字和边框),默认(灰色文字和边框)
      required: false,
      default: 'default'
    },
    className: {
      type: String,
      required: false,
      default: ''
    },
    disabled: {
      type: Boolean, // 是否禁用
      required: false,
      default: false
    },
    height: {
      type: [String, Number],
      required: false,
      default: 36
    }
  },
  data () {
    return {}
  },
  methods: {
    click (e) {
      if (this.disabled) {
        return
      }
      this.$emit('click', e)
    }
  }
}
</script>

<style lang="less" module>
.container {
  border: 1px solid #dddddd;
  box-sizing: border-box;
  border-radius: 18px;
  padding: 8px 18px;
  font-size: 14px;
  cursor: pointer;
  background: #ffffff;
  display: inline-block;
  line-height: 17px;
  white-space: nowrap;
  &[type="default"] {
    border-color: #dddddd;
    &:hover {
      background: #fafafa;
    }
    &:active {
        background: #F5F5F5;
    }
  }
  &[type="sub"] {
    color: #3360ff;
    border-color: #3360ff;
    &:hover {
      background: rgba(51, 96, 255, 0.05);
    }
    &:active {
        background: rgba(51, 96, 255, 0.1);
    }
  }
  &[type="primary"] {
    color: #ffffff;
    font-weight: 500;
    background: #3360ff;
    border-color: #3360ff;
    &:hover {
      background: linear-gradient(0deg, rgba(0, 0, 0, 0.04), rgba(0, 0, 0, 0.04)), #3360FF;
    }
    &:active {
        background: linear-gradient(0deg, rgba(0, 0, 0, 0.08), rgba(0, 0, 0, 0.08)), #3360FF;
    }
  }
  &[disabled] {
    cursor: not-allowed;
    color: #b8b8b8;
    border-color: #dddddd;
    background: #f5f5f5;
  }
}
</style>
