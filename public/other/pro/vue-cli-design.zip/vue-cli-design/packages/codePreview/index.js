
import CodePreview from './src/main.vue'
/**
 * @description: CodePreview
 * @param {*} option
 */

CodePreview.install = function (Vue) {
  Vue.component(CodePreview.name, CodePreview)
}

export default CodePreview
