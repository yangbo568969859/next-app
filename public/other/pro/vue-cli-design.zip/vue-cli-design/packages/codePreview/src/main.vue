/**
 * @description: 代码预览组件, 提供弹窗预览能力，（超出则滚动）
 *
 */
<template>
  <div>
    <a-modal
      v-model="show"
      class="code-preview"
      :class="[theme]"
      :footer="null"
      title="代码"
      width="936px"
      :body-style="bodyStyle"
      :destroy-on-close="true"
    >
      <div
        class="code"
        v-html="content"
      />
    </a-modal>
  </div>
</template>

<script>
import BasePreview from '../../basePreview/src/index.vue'

export default {
  name: 'CodePreview',
  extends: BasePreview,
  props: {
    theme: { // 主题颜色，默认为暗色系
      type: String,
      default: 'dark',
      validator: (value) => {
        return ['white', 'dark'].includes(value)
      }
    },
    codeSrc: {
      type: HTMLElement,
      default: null
    }
  },
  data () {
    return {
      bodyStyle: {},
      content: null
    }
  },
  watch: {
    codeSrc: {
      handler (val) {
        this.initCode(val)
      }
    }
  },
  methods: {
    initCode (val) { // 将HTMLElement转为String
      document.getHTML = function (ele, deep) {
        if (!ele || !ele.tagName) return ''
        var txt = document.createElement('div')
        var ax = document.createElement('div')
        var el = document.createElement('div')
        el.appendChild(ele.cloneNode(false))
        txt = el.innerHTML
        if (deep) {
          ax = txt.indexOf('>') + 1
          txt = txt.substring(0, ax) + ele.innerHTML + txt.substring(ax)
        }
        el = null
        return txt
      }
      this.content = document.getHTML(val, true)
    }
  }
}
</script>

<style lang="less" scoped>
.code-preview {
  /deep/ .ant-modal-content {
    .ant-modal-body {
      padding: 24px 24px;
      min-height: 334px;
    }
  }
}
.dark {
  /deep/ .ant-modal-content {
    background: #3E3E45;

    .ant-modal-header {
      background: #3E3E45;
      border-bottom: 0px solid #e8e8e8;
      box-shadow: inset 0px -1px 0px #4A4A4D;

      .ant-modal-title {
        color: #FFFFFF;
        font-weight: 600;
        font-size: 16px;
      }
    }

    .ant-modal-body {
      color: #fff;
      scrollbar-track-color: #3E3E45;

      &::-webkit-scrollbar {
        background-color: #3E3E45;
      }

      /*滚动条中间滑动部分*/
      &::-webkit-scrollbar-thumb {
        background-color: rgba(255, 255, 255, 0.65);
      }

      &::-webkit-scrollbar-corner {
        background-color: #3E3E45;
      }
    }

    .ant-modal-close {
      color: rgba(255, 255, 255, 0.65);
    }
  }

}

/deep/ .code {
  pre {
    overflow: auto;
    min-height: 286px;
    max-height: 66vh;
    margin: 0!important;
  }

  // 滚动条样式
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
    border-radius: 21px;
  }

  // 滚动条样式
  ::-webkit-scrollbar-thumb {
    border: 1px solid #606060;
    background: #2A2A2A;
    border-radius: 21px;
  }
}
</style>
