import BaseCropper from './src/BaseCropper.vue'

BaseCropper.install = function (Vue) {
  Vue.component(BaseCropper.name, BaseCropper)
}

export default BaseCropper
