<template>
  <div
    ref="modal"
    class="modal cropper-modal"
  >
    <div
      class="close"
      @click="close"
    />
    <div
      ref="background"
      class="moveable-background background"
      :style="getBackgroundStyle()"
    >
      <img
        ref="background-img"
        :src="data.url"
        alt=""
        draggable="false"
      >
    </div>
    <div
      ref="view"
      class="moveable-view view"
      :style="getViewStyle()"
    >
      <img
        ref="view-img"
        :src="data.url"
        alt=""
        draggable="false"
        :style="getViewImgStyle()"
      >
    </div>
    <canvas
      ref="cropper-canvas"
      class="cropper-canvas"
      :width="outterbox.width"
      :height="outterbox.height"
    />
    <img
      ref="cropper-img"
      crossOrigin="Anonymous"
      :src="cropperUrl"
      class="cropper-img"
    >
  </div>
</template>

<script>
import Moveable from './common/init-moveable.js'

export default {
  name: 'BaseCropper',
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  data () {
    return {
      moveableView: null,
      moveableBackground: null,
      targetbox: {},
      innerbox: {},
      outterbox: {},
      cropperData: {},
      originData: {},
      modalPos: {
        x: 0,
        y: 0,
      },
      cropperUrl: null,
    }
  },
  watch: {
    data: {
      handler (v) {
        this.innerbox = { ...v.innerbox }
        this.outterbox = { ...v.outterbox }
        this.targetbox = { ...v.targetbox }
        this.containerbox = v.containerbox ? { ...v.containerbox } : null
        this.originData = {
          innerbox: { ...v.innerbox },
          outterbox: { ...v.outterbox }
        }
        this.cropperUrl = `${v.url}${v.url.indexOf('?') === -1 ? '?' : '&'}${new Date().getTime()}`
      },
      immediate: true,
    },
  },
  mounted () {
    this.getModalPos()
    this.$nextTick(this.init)
  },
  methods: {
    waitingImg (imgDom) {
      // 随机后缀图片加载完成
      return new Promise((resolve) => {
        if (imgDom.complete) {
          resolve(true)
        }
        imgDom.onload = () => {
          resolve(true)
        }
      })
    },
    getViewStyle () {
      // 内框
      const { x, y } = this.modalPos
      const { width, height } = this.innerbox
      return {
        width: `${width}px`,
        height: `${height}px`,
        left: `${x}px`,
        top: `${y}px`,
      }
    },
    getViewImgStyle () {
      // 外框
      const { left, top, width, height } = this.outterbox
      return {
        width: `${width}px`,
        height: `${height}px`,
        left: `${left}px`,
        top: `${top}px`,
      }
    },
    getBackgroundStyle () {
      const { x, y } = this.modalPos
      const { left: oleft, top: otop, width: owidth, height: oheight } = this.outterbox
      // 背景
      return {
        width: `${owidth}px`,
        height: `${oheight}px`,
        left: `${oleft + x}px`,
        top: `${otop + y}px`,
      }
    },
    getModalPos () {
      const { left, top } = this.$refs.modal.getBoundingClientRect()
      this.modalPos = {
        x: this.targetbox.left - left,
        y: this.targetbox.top - top
      }
    },
    init () {
      // 初始化背景
      this.moveableBackground = new Moveable(this.$refs.modal, {
        target: this.$refs.background,
        className: 'moveable-background',
        renderDirections: ['nw', 'ne', 'se', 'sw'],
        draggable: true,
        resizable: true,
        keepRatio: true,
      })
      // 初始化视窗
      this.moveableView = new Moveable(this.$refs.modal, {
        target: this.$refs.view,
        className: 'moveable-view',
        renderDirections: ['n', 'nw', 'ne', 's', 'se', 'sw', 'e', 'w'],
        resizable: true,
      })
      // 建立碰撞连接
      this.moveableBackground.link(this.moveableView, 1)

      this.moveableBackground.on('drag', (e) => {
        // 背景移动时更新视窗
        const { translateX, translateY } = e
        const { translateX: translateX2, translateY: translateY2 } = this.moveableView.getPosition()
        this.$refs[
          'view-img'
        ].style.transform = `translate(${translateX - translateX2}px, ${translateY - translateY2}px)`
      })
      this.moveableBackground.on('resize', (e) => {
        // 背景缩放时更新视窗
        const { width, height, translateX, translateY } = e
        const { translateX: translateX2, translateY: translateY2 } = this.moveableView.getPosition()
        this.$refs['view-img'].style.width = `${width}px`
        this.$refs['view-img'].style.height = `${height}px`
        this.$refs[
          'view-img'
        ].style.transform = `translate(${translateX - translateX2}px, ${translateY - translateY2}px)`
      })
      this.moveableView.on('resize', (e) => {
        // 背景缩放时更新视窗
        const { translateX, translateY } = e
        const { translateX: translateX2, translateY: translateY2 } = this.moveableBackground.getPosition()
        this.$refs[
          'view-img'
        ].style.transform = `translate(${translateX2 - translateX}px, ${translateY2 - translateY}px)`
      })
      this.moveableView.on('resizeEnd', (e) => {
        console.log('resize end')
      })
    },
    /**
     * @description: 获取图片尺寸
     * @param {*} url
     * @return {*}
     */
    _getImgInfo (url) {
      return new Promise((resolve) => {
        const oImg = new Image()
        oImg.src = url
        oImg.style.position = 'fixed'
        oImg.style.zIndex = -9999
        oImg.style.visibility = 'hidden'

        oImg.onload = () => {
          resolve({
            width: oImg.naturalWidth,
            height: oImg.naturalHeight,
          })
        }
      })
    },
    /**
     * @description: 裁剪图片，取box的交集
     * @param {*} boxes
     * @param {*} backgroundBox
     * @return {*}
     */
    async cropperImg2 (boxes, { left: imgLeft, top: imgTop, width: imgWidth, height: imgHeight }) {
      let { left: rLeft, top: rTop, width, height } = boxes[0]
      let maxLeft = rLeft + width
      let maxTop = rTop + height

      // 计算最小box
      boxes.forEach((pos) => {
        rLeft = Math.max(rLeft, pos.left)
        rTop = Math.max(rTop, pos.top)
        maxLeft = Math.min(maxLeft, pos.left + pos.width)
        maxTop = Math.min(maxTop, pos.top + pos.height)
      })
      const rWidth = maxLeft - rLeft
      const rHeight = maxTop - rTop

      // 缩放比例
      const { width: fWidth, height: fHeight } = await this._getImgInfo(this.data.url)
      const xRatio = fWidth / imgWidth
      const yRatio = fHeight / imgHeight

      const canvas = this.$refs['cropper-canvas']
      const ctx = canvas.getContext('2d')

      // 解决高清屏模糊问题
      const dpr = window.devicePixelRatio || 1
      canvas.width = rWidth * dpr
      canvas.height = rHeight * dpr
      canvas.style.transform = `scale(${1 / dpr})`

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // 等待图片加载完成
      const imgDom = this.$refs['cropper-img']
      await this.waitingImg(imgDom)

      ctx.drawImage(imgDom,
        (rLeft - imgLeft) * xRatio,
        (rTop - imgTop) * yRatio,
        rWidth * xRatio,
        rHeight * yRatio,
        0, 0,
        rWidth * dpr,
        rHeight * dpr
      )

      return canvas.toDataURL('image/png')
    },
    /**
     * @description: 裁剪图片
     * @param {*} innerbox 内框坐标
     * @param {*} outterbox 外框坐标
     * @return {*}
     */
    async cropperImg ({ innerbox, outterbox }) {
      const { width: iw, height: ih } = innerbox
      const { width: ow, height: oh, left: ox, top: oy } = outterbox
      const { width, height } = await this._getImgInfo(this.data.url)
      const xRatio = width / ow
      const yRatio = height / oh

      const canvas = this.$refs['cropper-canvas']
      const ctx = canvas.getContext('2d')

      // 解决高清屏模糊问题
      const dpr = window.devicePixelRatio || 1
      canvas.width = iw * dpr
      canvas.height = ih * dpr
      canvas.style.transform = `scale(${1 / dpr})`

      ctx.clearRect(0, 0, iw * dpr, ih * dpr)

      // 等待图片加载完成
      const imgDom = this.$refs['cropper-img']
      await this.waitingImg(imgDom)

      ctx.drawImage(imgDom,
        -ox * xRatio,
        -oy * yRatio,
        iw * xRatio,
        ih * yRatio,
        0, 0,
        iw * dpr,
        ih * dpr
      )

      return canvas.toDataURL('image/png')
    },
    async submit () {
      const viewPosition = this.moveableView.getPosition()
      const backgroundPosition = this.moveableBackground.getPosition()

      const result = {
        url: this.data.url,
        targetbox: this.targetbox,
        innerbox: {
          width: viewPosition.w,
          height: viewPosition.h,
          left: this.originData.innerbox.left + viewPosition.translateX,
          top: this.originData.innerbox.top + viewPosition.translateY,
        },
        outterbox: {
          width: backgroundPosition.w,
          height: backgroundPosition.h,
          left: this.originData.outterbox.left + backgroundPosition.translateX - viewPosition.translateX,
          top: this.originData.outterbox.top + backgroundPosition.translateY - viewPosition.translateY
        },
      }

      if (this.data.cropImage) {
        // result.img = await this.cropperImg(result)
        const relativeOutterbox = {
          ...result.outterbox,
          ...{
            left: result.outterbox.left + result.innerbox.left,
            top: result.outterbox.top + result.innerbox.top
          }
        }
        const boxes = [result.innerbox, relativeOutterbox]
        if (this.containerbox) {
          boxes.push(this.containerbox)
        }
        result.img = await this.cropperImg2(boxes, relativeOutterbox)
      }
      return result
    },
    async _submit () {
      const result = await this.submit()
      this.$emit('submit', result)
    },
    async close () {
      this.$emit('action')
      await this._submit()
    },
    cancel () {
      return new Promise((resolve) => {
        resolve(this.data)
      })
    },
  },
}
</script>
<style lang="less" scoped>
@import "./less/reset.less";
</style>

<style lang="less" scoped>
.modal {
  position: relative;
  background: rgba(0, 0, 0, 0.2);
  width: 100%;
  height: 100%;
  .close {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
  }
  .view {
    position: absolute;
    overflow: hidden;
    z-index: 1;
    pointer-events: none;
    img {
      position: absolute;
      user-select: none;
    }
  }
  .background {
    position: absolute;
    overflow: hidden;
    opacity: 0.2;
    img {
      user-select: none;
      position: absolute;
      width: 100%;
      height: 100%;
      left: 0;
      top: 0;
    }
  }
  .cropper-canvas, .cropper-img {
    display: none;
  }
}
</style>
