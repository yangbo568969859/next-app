/**
 * @description: 模块配置
 */

export const MIN_WIDTH = 10
export const MIN_HEIGHT = 10

export const MIN_CONTROLLER_WIDTH = 30
export const MIN_CONTROLLER_HEIGHT = 30
