import Move from 'moveable'
import { MIN_WIDTH, MIN_HEIGHT, MIN_CONTROLLER_WIDTH, MIN_CONTROLLER_HEIGHT } from './config'

export default class Moveable {
  constructor (dom, options) {
    this.options = {
      className: 'moveable', // 可交互组件的class名称
      origin: false, // movable元素的中心点是否可见,default: true
      /** 拖拽属性 */
      draggable: false, // 是否支持可拖拽,default: false
      edgeDraggable: false, // 是否支持拖拽边框移动, default: false
      // throttleDrag: 0, // 拖拽时节流的单位(px),即每次拖拽的最小变动为100px, 默认不节流
      /** 更改大小属性 */
      resizable: false, // 是否支持更改大小
      // keepRatio: false, // 是否等比例更改大小, default: false
      renderDirections: ['nw', 'ne', 'sw', 'se'], // resize的句柄显示, default: ["n", "nw", "ne", "s", "se", "sw", "e", "w"]
    }
    Object.assign(this.options, options)
    this.options.className = `moveable ${this.options.className}`
    this.moveable = new Move(dom, this.options)
    this.events = {}
    this.relations = []
    this.position = undefined

    this._updatePositionInfo()

    this.moveable
      .on('dragStart', (e) => this.emit('dragStart', e))
      .on('drag', (e) => this._drag(e))
      .on('dragEnd', (e) => this.emit('dragEnd', e))
      .on('resizeStart', (e) => this._resizeStart(e))
      .on('resize', (e) => this._resize(e))
      .on('resizeEnd', (e) => this._resizeEnd(e))
  }

  getInstance () {
    return this.moveable
  }

  destroy () {
    this.moveable.destroy()
    this.moveable = null
  }

  setMoveableTarget (target) {
    this.moveable.target = target
  }

  _drag ({ target, beforeTranslate, width, height }) {
    let translateX = beforeTranslate[0]
    let translateY = beforeTranslate[1]
    const sizeInfo = { w: width, h: height, translateX, translateY, action: 'drag' }

    const { pass, position } = this._borderCheck(sizeInfo)
    if (!pass) {
      Object.assign(sizeInfo, position)
      translateX = position.translateX
      translateY = position.translateY
    }

    // 若发生碰撞, 隐藏重合操作点
    const linkData = this.relations[0]
    if (linkData.relation === 1) {
      // 通知内框隐藏操作点
      linkData.moveInstance.updateDirectionControllerForMove(linkData.moveInstance.getPosition(), {
        ...this.getPosition(),
        ...sizeInfo
      })
    }

    target.style.transform = `translate(${translateX}px, ${translateY}px)`
    this._updatePositionInfo(sizeInfo)
    this.emit('drag', {
      translateX, translateY
    })
  }

  _resizeStart ({ direction, target, _this, clientX, clientY }) {
    // 四角句柄按比例resize
    this.keepRatio = !!(direction[0] && direction[1])

    const linkData = this.relations[0]
    const position = linkData.moveInstance.getPosition()

    // 计算拖动的边界值，当碰撞检测不通过时则使用该边界值实现贴边处理
    this.resizeBorderBox = this._calcuResizeBorderBox({
      ...this.getPosition()
    }, position, linkData.relation, direction)

    // 最小框判定
    if (linkData.relation === -1) {
      this.minResizeBorderBox = this._calcuMinBorderBox(this.getPosition(), direction)
    }

    this.startPosition = { ...this.getPosition() }
    this.clientX = clientX
    this.clientY = clientY
  }

  /**
   * @description: 计算最小面积边界
   * @param {*} position1 {x, y, w, h, translateX, translateY}
   * @param {*} direction
   * @return {*} {
   *  {w, h, translateX, translateY}
   * }
   */
  _calcuMinBorderBox (position1, direction) {
    const { x: x1, y: y1, w: w1, h: h1, translateX: translateX1, translateY: translateY1 } = position1
    const result = { x: x1, y: y1, w: MIN_WIDTH, h: MIN_HEIGHT, translateX: translateX1, translateY: translateY1 }

    if (direction[0] === -1) {
      result.translateX += (w1 - MIN_WIDTH)
    }
    if (direction[1] === -1) {
      result.translateY += (h1 - MIN_HEIGHT)
    }
    return this._calcuResizeBorderBox(position1, result, 1, direction)
  }

  /**
   * @description: 计算resize边界
   * @param {*} position1 {x, y, w, h, translateX, translateY}
   * @param {*} position2 {x, y, w, h, translateX, translateY}
   * @param {*} relation 1: outside, 0, -1: inside
   * @param {*} direction
   * @return {*} {
   *  {w, h, translateX, translateY}
   * }
   */
  _calcuResizeBorderBox (position1, position2, relation, direction) {
    // 等比计算
    const { x: x1, y: y1, w: w1, h: h1, translateX: translateX1, translateY: translateY1 } = position1
    const { x: x2, y: y2, w: w2, h: h2, translateX: translateX2, translateY: translateY2 } = position2
    const [x1Left, x1Right, y1Top, y1Bottom, x2Left, x2Right, y2Top, y2Bottom] = [
      x1 + translateX1,
      x1 + translateX1 + w1,
      y1 + translateY1,
      y1 + translateY1 + h1,
      x2 + translateX2,
      x2 + translateX2 + w2,
      y2 + translateY2,
      y2 + translateY2 + h2,
    ]
    const ratio = w1 / h1

    const _calcuBorderMap = {
      '-1,-1': () => {
        if (y1Top === y2Top) {
          return position1
        }
        const useHeight = !!((x1Left - x2Left) / (y1Top - y2Top) > ratio)
        if (useHeight) {
          // 以Height为最大边界
          const rh = (y1Bottom - y2Top)
          const rw = rh * ratio
          const rty = y2Top - y1
          const rtx = translateX1 + w1 - rw
          return {
            h: rh,
            w: rw,
            translateX: rtx,
            translateY: rty,
          }
        } else {
          // 以Width为最大边界
          const rw = x1Right - x2Left
          const rh = rw / ratio
          const rtx = x2Left - x1
          const rty = translateY1 + h1 - rh
          return {
            h: rh,
            w: rw,
            translateX: rtx,
            translateY: rty,
          }
        }
      },
      '-1,1': () => {
        if (y1Bottom === y2Bottom) {
          return position1
        }
        const useHeight = !!((x1Left - x2Left) / (y2Bottom - y1Bottom) > ratio)
        if (useHeight) {
          // 以Height为最大边界
          const rh = y2Bottom - y1Top
          const rw = rh * ratio
          const rtx = translateX1 + w1 - rw // ow - rw
          return {
            h: rh,
            w: rw,
            translateX: rtx,
          }
        } else {
          const rw = x1Right - x2Left
          const rh = rw / ratio
          const rtx = x2Left - x1
          return {
            h: rh,
            w: rw,
            translateX: rtx,
          }
        }
      },
      '1,-1': () => {
        if (y1Top === y2Top) {
          return position1
        }
        const useHeight = !!((x1Right - x2Right) / (y2Top - y1Top) > ratio)
        if (useHeight) {
          // 以Height为最大边界
          const rh = y1Bottom - y2Top
          const rw = rh * ratio
          const rty = y2Top - y1
          return {
            h: rh,
            w: rw,
            translateY: rty,
          }
        } else {
          const rw = x2Right - x1Left
          const rh = rw / ratio
          const rty = translateY1 + h1 - rh
          return {
            h: rh,
            w: rw,
            translateY: rty,
          }
        }
      },
      '1,1': () => {
        if (y1Bottom === y2Bottom) {
          return position1
        }
        const useHeight = !!((x1Right - x2Right) / (y1Bottom - y2Bottom) > ratio)
        if (useHeight) {
          // 以Height为最大边界
          const rh = y2Bottom - y1Top
          const rw = rh * ratio
          return {
            h: rh,
            w: rw,
          }
        } else {
          const rw = x2Right - x1Left
          const rh = rw / ratio
          return {
            h: rh,
            w: rw,
          }
        }
      },
      '-1,0': () => {
        const rw = x1Right - x2Left
        const rtx = x2Left - x1
        return {
          w: rw,
          translateX: rtx,
        }
      },
      '1,0': () => {
        const rw = x2Right - x1Left
        return {
          w: rw,
        }
      },
      '0,-1': () => {
        const rh = y1Bottom - y2Top
        const rty = y2Top - y1
        return {
          h: rh,
          translateY: rty
        }
      },
      '0,1': () => {
        const rh = y2Bottom - y1Top
        return {
          h: rh,
        }
      }
    }
    return _calcuBorderMap[direction.join()]()
  }

  _resize ({
    target, // DOM 初始化moveable的target元素
    width, // number 元素(target)的css宽度
    height, // number 元素(target)的css高度
    drag, // 元素的拖拽事件,同onDrag的参数
    direction, // 判断resize的句柄[1,1]为右下,[-1,-1]为左上
    clientX,
    clientY,
  }) {
    let { w, h, translateX, translateY } = this.startPosition
    const deltaX = clientX - this.clientX
    const deltaY = this.keepRatio
      ? (h / w * deltaX * (direction[0] + direction[1] === 0 ? -1 : 1))
      : clientY - this.clientY

    if (direction[0] === -1) {
      width = w - deltaX
      translateX += deltaX
    } else if (direction[0] === 1) {
      width = w + deltaX
    }
    if (direction[1] === -1) {
      height = h - deltaY
      translateY += deltaY
    } else if (direction[1] === 1) {
      height = h + deltaY
    }

    // 计算后的样式
    const sizeInfo = { w: (width), h: (height), translateX: (translateX), translateY: (translateY) }

    // 面积过小修正
    if (width < MIN_WIDTH || height < MIN_HEIGHT) {
      Object.assign(sizeInfo, this.minResizeBorderBox)
    }

    // 碰撞检测
    const { pass } = this._borderCheck(sizeInfo)
    if (!pass) {
      // 越界，贴边处理
      Object.assign(sizeInfo, this.resizeBorderBox)
    }

    // 若发生碰撞, 隐藏重合操作点
    const linkData = this.relations[0]
    if (linkData.relation === 1) {
      // 通知内框隐藏操作点
      linkData.moveInstance.updateDirectionControllerForMove(linkData.moveInstance.getPosition(), {
        ...this.getPosition(),
        ...sizeInfo
      })
    } else {
      this.updateDirectionControllerForMove({
        ...this.getPosition(),
        ...sizeInfo
      }, linkData.moveInstance.getPosition(), direction)
    }

    width = sizeInfo.w
    height = sizeInfo.h
    translateX = sizeInfo.translateX
    translateY = sizeInfo.translateY

    target.style.transform = `translate(${translateX}px, ${translateY}px)`
    target.style.width = `${width}px`
    target.style.height = `${height}px`
    this._updatePositionInfo(sizeInfo)

    this.emit('resize', {
      direction,
      width,
      height,
      translateX,
      translateY,
    })
  }

  _resizeEnd (e) {
    // 若面积过小，保留右下角拖动点
    const { w, h } = this.getPosition()
    if (w < MIN_CONTROLLER_WIDTH || h < MIN_CONTROLLER_HEIGHT) {
      if (this.moveable.renderDirections.includes('se')) {
        this.moveable.renderDirections = ['se']
      } else {
        this.moveable.renderDirections = []
      }
    }
    this.emit('resizeEnd', e)
  }

  /**
   * @description: 获取符合碰撞检测的近似点
   * @param {*} position1 {x, y, w, h, translateX, translateY}
   * @param {*} position2 {x, y, w, h, translateX, translateY}
   * @param {*} relation 1: outside, 0, -1: inside
   * @return {*} {translateX, translateY}
   */
  _calcuApproximateForDrag (position1, position2, relation) {
    const pickLT = relation === 1 ? Math.min : Math.max
    const pickRB = relation === 1 ? Math.max : Math.min
    let { x: x1, y: y1, w: w1, h: h1, translateX: translateX1, translateY: translateY1 } = position1
    const { x: x2, y: y2, w: w2, h: h2, translateX: translateX2, translateY: translateY2 } = position2

    if (pickRB(x1 + translateX1 + w1 - (x2 + translateX2 + w2), 0) === 0) {
      translateX1 = x2 + translateX2 + w2 - x1 - w1
    }
    if (pickLT(x1 + translateX1 - (x2 + translateX2), 0) === 0) {
      translateX1 = x2 + translateX2 - x1
    }
    if (pickRB(y1 + translateY1 + h1 - (y2 + translateY2 + h2), 0) === 0) {
      translateY1 = y2 + translateY2 + h2 - y1 - h1
    }
    if (pickLT(y1 + translateY1 - (y2 + translateY2), 0) === 0) {
      translateY1 = y2 + translateY2 - y1
    }

    return {
      translateX: translateX1,
      translateY: translateY1,
    }
  }

  /**
   * @description: 边界判定
   * @param {*} dragInfo {
   *  translateX
   *  translateY
   *  width
   *  height
   *  action: drag or resize
   * }
   * @return {*}
   */
  _borderCheck (dragInfo) {
    // 平级检测暂不提供
    const linkData = this.relations[0]
    if (!linkData) {
      // 无需碰撞检测
      return { pass: true }
    }
    // 碰撞检测
    const position = linkData.moveInstance.getPosition()
    const thisPosition = { ...this.getPosition(), ...dragInfo }

    const pass =
      this[linkData.relation === 1 ? '_checkOutside' : '_checkInside'](thisPosition, position)

    if (!pass) {
      const newPosition = dragInfo.action === 'drag'
        ? this._calcuApproximateForDrag(thisPosition, position, linkData.relation)
        : () => {}
      return {
        pass,
        position: newPosition
      }
    }
    return { pass }
  }

  /**
   * @description: 多个moveable实例之间建立关系，用于碰撞检测
   * @param {*} moveInstance 待与本实例建立关系的moveable实例
   * @param {*} relation 1: outside, 0, -1: inside
   * @param {*} isEndPoint 是否需要反向建立
   * @return {*}
   */
  link (moveInstance, relation, isEndPoint) {
    if (relation === undefined) {
      relation = this._checkRelation(moveInstance.getPosition())
    }

    this.relations.push({
      moveInstance,
      relation
    })

    // 操作点隐藏
    const linkData = this.relations[0]
    if (linkData && linkData.relation === -1) {
      this.updateDirectionControllerForMove(this.getPosition(), linkData.moveInstance.getPosition())
    }

    relation = -relation
    !isEndPoint && moveInstance.link(this, relation, true)
  }

  /**
   * @description: 位置关系判断(仅在link时做一次)
   * @param {*} position
   * @return {*}  1: 本实例是外层 -1: 内层 0: 平级
   */
  _checkRelation (position) {
    const thisPosition = this.getPosition()
    // TODO 旋转情况不适用
    if (this._checkInside(thisPosition, position)) {
      return -1
    } else if (this._checkOutside(thisPosition, position)) {
      return 1
    } else {
      return 0
    }
  }

  /**
   * @description: 判断position1是否完全落在position2中
   * @param {*} position1
   * @param {*} position2
   * @return {*} boolean
   */
  _checkInside (position1, position2) {
    const nw1 = {
      x: position1.x + position1.translateX,
      y: position1.y + position1.translateY,
      w: position1.w,
      h: position1.h,
    }
    const nw2 = {
      x: position2.x + position2.translateX,
      y: position2.y + position2.translateY,
      w: position2.w,
      h: position2.h,
    }

    if (
      nw1.x >= nw2.x &&
      nw1.y >= nw2.y &&
      nw1.x + nw1.w <= nw2.x + nw2.w + 1 &&
      nw1.y + nw1.h <= nw2.y + nw2.h + 1
    ) {
      return true
    }
    return false
  }

  /**
   * @description: 判断position1是否包裹position2中
   * @param {*} position1
   * @param {*} position2
   * @return {*} boolean
   */
  _checkOutside (position1, position2) {
    const nw1 = {
      x: position1.x + position1.translateX,
      y: position1.y + position1.translateY,
      w: position1.w,
      h: position1.h,
    }
    const nw2 = {
      x: position2.x + position2.translateX,
      y: position2.y + position2.translateY,
      w: position2.w,
      h: position2.h,
    }

    if (
      nw1.x <= nw2.x &&
      nw1.y <= nw2.y &&
      nw1.x + nw1.w >= nw2.x + nw2.w - 1 &&
      nw1.y + nw1.h >= nw2.y + nw2.h - 1
    ) {
      return true
    }
    return false
  }

  /**
   * @description: 获取当前moveable包围盒的四个顶点
   * @return Array<{x: number, y: number}>
   */
  getPosition () {
    return this.position
  }

  /**
   * @description: 更新位置
   * @param {*} data {
   *  translateX, translateY
   * }
   */
  _updatePositionInfo (data = {}) {
    if (!this.position) {
      const { x, y, width: w, height: h } = this.options.target.getBoundingClientRect()
      this.position = {
        x, y, w, h, translateX: 0, translateY: 0,
      }
    }
    Object.assign(this.position, data)
  }

  /**
   * @description: 隐藏controller判定(最小面积)
   * @param {*} data {
   *  w, h
   * }
   * @return {*}
   */
  _needHiddenControllerForMinRect (data = {}) {
    if (data.w < MIN_CONTROLLER_WIDTH || data.h < MIN_CONTROLLER_HEIGHT) {
      return true
    }
    return false
  }

  /**
   * @description: 隐藏controller判定(drag or resize)
   * @param {*} position1
   * @param {*} position2
   * @return {*} {
   *    hideDirection: Array<string>
   *    hideEdges: Array<string>
   * }
   */
  _needHiddenControllerForMove (position1, position2) {
    const hideDirections = []
    const [
      x1Left,
      x1Right,
      y1Top,
      y1Bottom,
      x2Left,
      x2Right,
      y2Top,
      y2Bottom,
    ] = [
      position1.x + position1.translateX,
      position1.x + position1.translateX + position1.w,
      position1.y + position1.translateY,
      position1.y + position1.translateY + position1.h,
      position2.x + position2.translateX,
      position2.x + position2.translateX + position2.w,
      position2.y + position2.translateY,
      position2.y + position2.translateY + position2.h,
    ]
    if (Math.abs(x1Left - x2Left) <= 1) {
      if (Math.abs(y1Top - y2Top) <= 1) {
        hideDirections.push('nw')
      }
      if (Math.abs(y1Bottom - y2Bottom) <= 1) {
        hideDirections.push('sw')
      }
    }
    if (Math.abs(x1Right - x2Right) <= 1) {
      if (Math.abs(y1Top - y2Top) <= 1) {
        hideDirections.push('ne')
      }
      if (Math.abs(y1Bottom - y2Bottom) <= 1) {
        hideDirections.push('se')
      }
    }
    return {
      hideEdges: Array.from(new Set(hideDirections.join('').split(''))),
      hideDirections,
    }
  }

  /**
   * @description: 隐藏controller判定(drag or resize)
   * @param {*} position1
   * @param {*} position2
   * @param {*} direction
   */
  updateDirectionControllerForMove (position1, position2, direction = [1, 1]) {
    //  最小面积下需要隐藏的点
    const hideDirections = this.calcuHideDirectionForMinRect(position1, direction)
    const exsitDirections = this.options.renderDirections.filter((item) => !hideDirections.includes(item))
    // 碰撞检测需要向内移动的点、边
    const { hideDirections: needMoveDirections, hideEdges } = this._needHiddenControllerForMove(position1, position2)
    const moveInDirections = exsitDirections.filter((item) => needMoveDirections.includes(item))
    // 碰撞检测需要向外移动的点
    const moveOutDirections = exsitDirections.filter((item) => !moveInDirections.includes(item))

    // 隐藏边的样式
    const edgeClassNames = hideEdges.map((edge) => `hide-${edge}-line`).join(' ')

    // 向内移动点的样式
    const pointInClassNames = moveInDirections.filter(p => p.length > 1)
      .map((p) => `move-in-${p}-point`).join(' ')

    // 向外移动点的样式
    const pointOutClassNames = moveOutDirections.filter(p => p.length > 1)
      .map((p) => `move-out-${p}-point`).join(' ')

    const newClass = `${this.options.className} ${edgeClassNames} ${pointInClassNames} ${pointOutClassNames}`
    if (this.moveable.className !== newClass) {
      this.moveable.className = newClass
    }

    // 面积过小时，隐藏部分节点
    if (this.moveable.renderDirections.join() !== exsitDirections.join()) {
      this.moveable.renderDirections = exsitDirections
    }
  }

  /**
   * @description: 获取最小面积下需要隐藏的控制点
   * @param {*} data {
   *  w, h
   * }
   * @param {*} direction
   * @return {*} needHideDirections
   */
  calcuHideDirectionForMinRect (data = {}, direction) {
    if (this._needHiddenControllerForMinRect(data)) {
      const di = 'n sw e'
      const saveDirections = ['se'].concat([
        `${di[Number(direction[1]) + 1]}${di[Number(direction[0]) + 4]}`.trim()
      ])
      return this.options.renderDirections.filter((item) => !saveDirections.includes(item))
    }
    return []
  }

  /**
   * 注册事件和处理函数
   * @param event
   * @param fn
   */
  on (event, fn) {
    if (Array.isArray(this.events[event])) {
      for (let i = 0, l = this.events[event].length; i < l; i++) {
        this.on(this.events[event][i], fn)
      }
    } else {
      // 存在直接push, 不存在创建为空数组再push
      (this.events[event] || (this.events[event] = [])).push(fn)
    }
  }

  /**
   * 触发某事件所有回调并带参数
   * @param event
   */
  emit (event) {
    if (this.events[event]) {
      const cbs = [...this.events[event]]
      for (let i = 0, l = cbs.length; i < l; i++) {
        try {
          cbs[i].apply(null, [...arguments].slice(1))
        } catch (e) {
          // eslint-disable-next-line no-new
          new Error(e, `event handler for "${event}"`)
        }
      }
    }
  }
}
