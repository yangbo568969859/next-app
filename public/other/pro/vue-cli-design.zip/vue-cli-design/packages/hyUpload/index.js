
import HyUpload from './src/main.vue'
/**
 * @description: HyUpload
 * @param {*} option
 */

HyUpload.install = function (Vue) {
  Vue.component(HyUpload.name, HyUpload)
}

export default HyUpload
