<template>
  <div>
    <a-upload
      :multiple="isMultiple"
      :accept="accept"
      :file-list="fileList"
      :limit="limit"
      :before-upload="beforeUpload"
      :show-upload-list="isShowList"
      :custom-request="handleChange"
      :remove="removeFile"
    >
      <!-- 可自定义样式 -->
      <slot name="content">
        <a-button v-if="isHidden">
          <a-icon type="upload" /> 上传文件
        </a-button>
      </slot>
      <!-- 可配置文字提示 -->
      <slot name="tips" />
    </a-upload>
  </div>
</template>

<script>
import { Button, Upload, Icon, message } from 'ant-design-vue'
import NosUploader from '../../nosUploader'

export default {
  name: 'HyUpload',
  components: {
    [Upload.name]: Upload,
    [Icon.name]: Icon,
    [Button.name]: Button
  },
  props: {
    beforeUploadHook: { // 自定义校验方法
      type: Function,
      default: () => {
        return true
      }
    },
    accept: { // 文件格式
      type: String
    },
    limit: { // 文件大小
      type: Number,
      default: 10
    },
    isMultiple: { // 是否批量上传
      type: Boolean,
      default: false
    },
    fileUrl: {
      type: Array,
      default () {
        return []
      }
    },
    uploadParams: { // nos上传参数
      type: Object,
      default () {
        return {
        }
      }
    },
    length: { // 文件个数
      type: Number,
      default: 1
    },
    isShowList: { // 是否显示文件列表
      type: Boolean,
      default: true
    },
    isShow: { // 是否隐藏按钮
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      fileList: [],
      newList: [],
      isLimit: true,
      uploader: null,
      list: [],
      number: true,
      isHidden: true,
      getFileList: []
    }
  },
  watch: {
    fileUrl: { // 回显文件列表
      deep: true,
      handler: function (newval) {
        if (newval.length >= 1) {
          this.fileList = newval
        }
      }
    },
    fileList (val) { // 控制按钮隐藏
      if (this.isShow && val.length === this.length) {
        this.isHidden = false
      } else {
        this.isHidden = true
      }
    }
  },
  mounted () {
    if (this.fileUrl && this.fileUrl.length > 0) { // 首次加载就有值时直接显示
      this.fileList = this.fileUrl
    }
    this.uploader = NosUploader({
      app: this.uploadParams.app ? this.uploadParams.app : '',
      code: this.uploadParams.code,
      securityCheck: false,
      singleton: false
    })
  },
  methods: {
    getList () { // 自定义获取上传列表
      return new Promise(resolve => {
        // fileList为空或者已经上传完成
        if (this.fileList.every(e => e.status === 'done') || this.fileList.length === 0) {
          resolve(this.fileList)
        }
        this.getFileList.push(resolve)
      })
    },
    handleChange (info) {
      console.log('info', info)
      const type = info.file.name.split('.').pop()
      this.fileList.push({
        uid: info.file.uid,
        name: info.file.name,
        size: info.file.size / 1024, // 大小转kb
        status: 'uploading',
        url: '',
        key: '',
        form: type
      })
      this.newList.push(info)
      this.$emit('uploadChange', true) // 上传状态
      const reg = /^[0-9A-Za-z]{32}/
      for (let i = 0; i < localStorage.length; i++) { // 每次上传前移除上传的缓存
        if (reg.test(localStorage.key(i).toString())) {
          localStorage.removeItem(localStorage.key(i))
        }
      }
      this.uploader.uploads([info.file], {}).then((res) => {
        this.fileList.forEach((ele) => {
          if (res[0].target._originFile.uid === ele.uid) {
            ele.status = 'done'
            ele.url = res[0].url
            ele.key = res[0].objectName
          }
        })
        const uploaded = []
        const notUploaded = []
        this.fileList.forEach((item) => {
          if (item.status && item.status === 'done') { // 上传成功的文件
            uploaded.push(item)
          } else if (item.status && item.status === 'error') { // 上传失败的文件
            notUploaded.push(item)
          }
        })
        this.newList.map((val, index) => {
          if (val.file.uid === res[0].target._originFile.uid) {
            this.newList.splice(index, 1)
          }
        })
        if (this.newList.length === 0) {
          this.getFileList.forEach(e => {
            e(this.fileList)
          })
          this.$emit('success', uploaded)
          this.getFileList = []
          this.$emit('uploadChange', false)
        }
        this.list = []
        if (notUploaded.length !== 0) {
          this.$emit('fail', notUploaded)
          this.$emit('uploadChange', false)
        }
      }).catch((err) => {
        this.list = []
        this.$emit('uploadChange', false)
        throw new Error(err)
      })
    },
    removeFile (file) {
      if (file.status === 'uploading') { // 上传过程中不允许删除
        message.error('上传未完成不可删除')
        return false
      } else {
        this.fileList.forEach((ele, index) => {
          if (file.uid === ele.uid) {
            this.fileList.splice(index, 1)
          }
        })
      }
    },
    // 验证文件大小 true: 超出限制
    limitDetect (fileSize) {
      return fileSize / 1024 / 1024 > Number(this.limit)
    },
    acceptFile (name) {
      let flag = true
      if (this.accept) { // 文件类型不做限制不判断
        flag = this.accept.split(',').some((item) => {
          return item === '.' + name.split('.').pop().toLowerCase() // 上传文件后缀大写
        })
      }
      return flag
    },
    beforeUpload (file) {
      if (!this.beforeUploadHook(file)) {
        return false
      }
      if (this.list.length + 1 > this.length || this.fileList.length + this.list.length + 1 > this.length) {
        if (this.number) {
          this.number = false
          message.error(`最多只能上传${this.length}个文件`)
        }
        return false
      }
      this.number = true
      if (!this.acceptFile(file.name)) {
        message.error('上传文件格式不正确')
        return false
      }
      if (file.size === 0) {
        message.error('请上传正确的文件')
        return false
      }
      if (this.limitDetect(file.size)) {
        if (this.limit >= 1024) {
          message.error(`文件大小不能超过${this.limit / 1024}G`)
        } else {
          message.error(`文件大小不能超过${this.limit}M`)
        }
        return false
      }
      if (this.length === 1) {
        this.fileList = []
      }
      this.list.push(file)
    }
  }
}
</script>
