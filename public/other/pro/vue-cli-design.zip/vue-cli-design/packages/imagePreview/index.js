
import ImagePreview from './src/main.vue'
/**
 * @description: ImagePreview
 * @param {*} option
 */

ImagePreview.install = function (Vue) {
  Vue.component(ImagePreview.name, ImagePreview)
}

export default ImagePreview
