/**
 * @description: 图片预览组件, 提供弹窗预览能力，支持自适应图片尺寸
 *
 */
<template>
  <div>
    <a-modal
      :class="[theme]"
      v-model="show"
      :footer="null"
      title="预览"
      :width="modalWidth + 10"
      :bodyStyle="bodyStyle"
    >
      <img
        :src="src"
        :width="modalWidth"
        :height="modalHeight"
      />
    </a-modal>
  </div>
</template>

<script>
import BasePreview from '../../basePreview/src/index.vue'

export default {
  extends: BasePreview,
  name: 'ImagePreview',
  data () {
    return {
      bodyStyle: { padding: '5px 5px' }
    }
  },
  props: {
    theme: {
      type: String,
      default: 'white',
      validator: (value) => {
        return ['white', 'dark'].includes(value)
      }
    }
  },
  watch: {
    src: {
      handler () {
        this.getImageWidth()
      },
      immediate: true
    }
  },
  methods: {
    getImageWidth () {
      const img = new Image()
      img.src = this.src
      // 如果图片被缓存，则直接返回缓存数据
      if (img.complete) {
        this.setStyle(img)
      } else {
        img.onload = () => {
          this.setStyle(img)
        }
      }
    }
  }
}
</script>
<style lang="less" scoped>
.dark {
  /deep/ .ant-modal-content {
    background: #3E3E45;

    .ant-modal-header {
      background: #3E3E45;
      border-bottom: 0px solid #e8e8e8;
      box-shadow: inset 0px -1px 0px #4A4A4D;

      .ant-modal-title {
        color: #FFFFFF;
        font-weight: 600;
        font-size: 16px;
      }
    }

    .ant-modal-close {
      color: rgba(255, 255, 255, 0.65);
    }
  }
}
</style>
