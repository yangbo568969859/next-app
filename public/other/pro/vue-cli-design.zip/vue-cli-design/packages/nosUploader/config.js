/**
 * @description: 模块配置
 */

export const UPLOAD_URL = 'https://wanproxy-web.127.net'
