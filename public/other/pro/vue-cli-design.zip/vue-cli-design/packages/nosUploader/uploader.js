import {
  NOSWebClass,
  // NOSDefaultUploader,
  NOSBlockUploader,
  // NOSConcurrentUploader
} from '@winman-f2e/nos-js-web'
import { UPLOAD_URL } from './config'
import BaseUploader from '../baseUploader/uploader'

/**
 * 上传实例
 */
class NosUploader extends BaseUploader {
  /**
   * @description: 基础版构造函数
   * @param {*} option
   */
  constructor (option = {}) {
    super()
    this.NOSUploader = new NOSWebClass(NOSBlockUploader)
    this.option = option
  }

  /**
   * @description: 文件上传
   * @param {*} file: input files
   * @param {*} *option {
   *    *fileName: 返回的文件名
   *    *download: 0: 图片url, 1: 下载链接
   * }
   */
  upload (file, option) {
    if (!this._paramVerify(option)) {
      return
    }
    // 获取上传凭证、分区信息
    this._fetchUploadInfo(file, {
      fileName: option.fileName
    }).then((res) => {
      const { objectName: objectKey, objectName, bucketName, token } = res

      // 更新分区设置
      this._updateAPI(bucketName, objectKey)
      // 设置上传凭证
      this._useGetToken({ bucketName, objectKey, token })
      // 上传
      this._upload(file, {
        objectName,
        ...option,
      })
    })
  }

  /**
   * @description: 参数校验
   * @param option {
   *    *fileName: 返回的文件名
   *    *download: 0: 图片url, 1: 下载链接
   * }
   * @return boolean
   */
  _paramVerify (option) {
    if ((option.download || option.fileName) && option.thumbnail) {
      this.option.reject(new Error('参数thumbnail与fileName、download不能共存'))
      return false
    }
    return true
  }

  /**
   * @description: 获取图片尺寸
   * @param {*} file
   * @return {*}
   */
  _getImgInfo (file) {
    return new Promise((resolve) => {
      if (!/\.(jpg|jpeg|png|GIF|JPG|PNG)$/.test(file.name)) {
        resolve({})
      }
      const reader = new FileReader()
      reader.onload = ({ target: { result } }) => {
        const oImg = new Image()
        oImg.src = result
        oImg.style.position = 'fixed'
        oImg.style.zIndex = -9999
        oImg.style.visibility = 'hidden'

        oImg.onload = () => {
          resolve({
            width: oImg.naturalWidth,
            height: oImg.naturalHeight,
          })
        }
      }
      reader.readAsDataURL(file)
    })
  }

  _updateAPI (bucketName, objectKey) {
    const url = UPLOAD_URL
    objectKey = encodeURIComponent(objectKey)
    this.NOSUploader.updateAPI({
      NOS_UPLOAD: {
        url,
        methods: 'POST'
      },
      NOS_GET_OBJECT: {
        url: `${url}/{objectKey}`,
      },
      NOS_BLOCK_UPLOAD: {
        // url,
        url: `${url}/${bucketName}/${objectKey}`,
        methods: 'POST',
      },
      FETCH_BLOCK_UPLOAD_CONTEXT: {
        url: `${url}/{objectKey}`,
        methods: 'GET',
      },
      FETCH_BLOCK_UPLOAD_SERVER: {
        url,
        methods: 'GET',
      },
      // NOS_CONCURRENT_UPLOAD: {
      //   url: `${url}/{objectKey}`,
      // }
    })
  }

  _upload (file, option) {
    // 上传
    const task = this.NOSUploader.createUploadTask(file)
    // 监听上传完成
    task.addListener('complete', (res) => {
      // const promiseList = [this._getPath(this._pick(option, 'objectName', 'download', 'thumbnail'))]
      // if (!/\.(jpg|jpeg|png|GIF|JPG|PNG)$/.test(file.name)) {
      //   promiseList.push(this._getImgInfo(file))
      // }
      // Promise.all(promiseList)
      //   .then(([url, imageInfo = {}]) => {
      //     this.option.resolve(
      //       {
      //         ...imageInfo,
      //         ...res,
      //         url,
      //         objectName: option.objectName,
      //       })
      //   })
      this._getPath(this._pick(option, 'objectName', 'download', 'thumbnail')).then((url) => {
        const result = {
          ...res,
          url,
          objectName: option.objectName,
        }
        if (/\.(jpg|jpeg|png|GIF|JPG|PNG)$/.test(file.name)) {
          this._getImgInfo(file).then((imageInfo) => {
            console.log({
              ...result,
              ...imageInfo
            })
            this.option.resolve({
              ...result,
              ...imageInfo
            })
          })
        } else {
          this.option.resolve(result)
        }
      })
    })
    task.addListener('progress', ({ data, target: { _originFile: file } }) => {
      this.option.onProgress({ name: file.name, ...data })
    })
    // 监听上传错误
    task.addListener('error', (e) => {
      this.option.reject(e.data)
    })
    // 开始上传
    task.upload()
  }

  _useGetToken (data) {
    this.NOSUploader.useGetToken((uploader) => {
      return data
    })
  }
}

export default NosUploader
