/**
 * @description: ParseUrl
 * @param {*} url
 */
function ParseUrl (url) {
  const a = document.createElement('a') // 创建一个a标签，并将url赋值给标签的href属性
  a.href = url
  return {
    source: url,
    protocol: a.protocol.replace(':', ''), // 协议
    host: a.hostname, // 主机名称
    port: a.port, // 端口号
    query: a.search, // 查询字符串
    params: (function () { // 查询参数
      if (a.href.indexOf('?') === -1) {
        return {}
      }
      const arrSearch = url.split('?')[1].split('&') // 分割地址参数部分
      const obj = {}
      arrSearch.forEach(item => { // 遍历数组，拆分为键值对
        const [k, v] = item.split('=')
        obj[k] = v
      })
      return obj
    })(),
    hash: a.hash.replace('#', ''), // 哈希参数
    segments: a.pathname.replace(/^\//, '').split('/') // 路径片段
  }
}

export default ParseUrl
