
import PdfPreview from './src/main.vue'
/**
 * @description: PdfPreview
 * @param {*} option
 */

PdfPreview.install = function (Vue) {
  Vue.component(PdfPreview.name, PdfPreview)
}

export default PdfPreview
