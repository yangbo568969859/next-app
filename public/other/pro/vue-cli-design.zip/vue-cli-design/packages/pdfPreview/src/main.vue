/**
 * @description: PDF预览组件, 提供弹窗预览能力
 *
 */
<template>
  <div>
    <a-modal
      v-model="show"
      :footer="null"
      title="预览"
      centered
      :width="modalWidth + 10"
      :bodyStyle="bodyStyle"
      :destroyOnClose="true"
    >
      <iframe :src="pdfUrl" :width="modalWidth" :height="modalHeight">
        This browser does not support PDF!
      </iframe>
    </a-modal>
  </div>
</template>

<script>
import BasePreview from '../../basePreview/src/index.vue'

export default {
  extends: BasePreview,
  name: 'PdfPreview',
  data () {
    return {
      bodyStyle: { padding: '5px 5px' },
      modalWidth: window.innerWidth * 0.8,
      modalHeight: window.innerHeight * 0.8
    }
  },
  computed: {
    pdfUrl () {
      return `${this.src}#view=FitH`
    }
  }
}
</script>
