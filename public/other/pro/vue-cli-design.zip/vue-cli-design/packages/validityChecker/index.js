/**
 * @description: ValidityChecker
 * @param {*} option {
 *  type: 类型 email/phone
 *  value: 检验内容
 * }
 */
function ValidityChecker (option) {
  if (!option || !option.type || !option.value) throw new Error('校验类型与内容不能为空')
  let result = false
  if (option.type === 'email') {
    result = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(option.value) // 邮箱
  } else if (option.type === 'phone') {
    result = /^1[3,4,5,6,7,8,9][0-9]{9}$/.test(option.value.toString()) // 中国大陆手机
  } else {
    throw new Error('校验类型错误')
  }
  return result
}

export default ValidityChecker
