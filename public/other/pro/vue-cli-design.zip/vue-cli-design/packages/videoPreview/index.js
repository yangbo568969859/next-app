
import VideoPreview from './src/main.vue'
/**
 * @description: VideoPreview
 * @param {*} option
 */

VideoPreview.install = function (Vue) {
  Vue.component(VideoPreview.name, VideoPreview)
}

export default VideoPreview
