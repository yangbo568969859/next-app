/**
 * @description: 视频预览组件, 提供弹窗预览能力，支持自适应视频尺寸
 *
 */
<template>
  <div>
    <a-modal
      v-model="show"
      :footer="null"
      title="预览"
      :width="modalWidth + 10"
      :body-style="bodyStyle"
      :destroy-on-close="true"
    >
      <video
        crossOrigin="anonymous"
        :width="modalWidth"
        :height="modalHeight"
        :controls="controls"
        muted="muted"
        :autoplay="autoplay"
        @loadeddata="loadeddata"
      >
        <source :src="src" type="video/mp4">
        <source :src="src" type="video/ogg">
        Your browser does not support the video tag.
      </video>
    </a-modal>
  </div>
</template>

<script>
import BasePreview from '../../basePreview/src/index.vue'

export default {
  extends: BasePreview,
  name: 'VideoPreview',
  data () {
    return {
      bodyStyle: { padding: '5px 5px 0' }
    }
  },
  props: {
    controls: {
      type: Boolean,
      default: true
    },
    muted: {
      type: Boolean,
      default: false
    },
    autoplay: {
      type: Boolean,
      default: true
    }
  },
  methods: {
    loadeddata (video) {
      const { videoWidth: width, videoHeight: height } = video.target
      this.setStyle({ width, height })
    }
  }
}
</script>
