import BaseWebEnv from './webenv'
/**
 * @description: webEnv
 * @param {*} option
 */
function webEnv (option) {
  return new BaseWebEnv(option)
}

export default webEnv
