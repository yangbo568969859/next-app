/**
 * 组件库引用入口
 */
import '../packages/font/iconfont.js'
import { version } from '../package.json'
import HelloWorld from '../packages/helloWorld/index.js'
import NosUploader from '../packages/nosUploader/index'
import OssUploader from '../packages/ossUploader/index'
import Cropper from '../packages/cropper/index.js'
import BaseButton from '../packages/button/index.js'
import '../packages/theme-chalk/index.less'
import CodePreview from '../packages/codePreview'
import ImagePreview from '../packages/imagePreview'
import PdfPreview from '../packages/pdfPreview'
import VideoPreview from '../packages/videoPreview'
import ParseUrl from '../packages/parseUrl'
import ValidityChecker from '../packages/validityChecker'
import HyUpload from '../packages/hyUpload'
import WebEnv from '../packages/webEnv/index'
const components = {
  HelloWorld,
  Cropper,
  BaseButton
}

const install = function (Vue) {
  Object.values(components).forEach(component => {
    Vue.component(component.name, component)
  })
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export { NosUploader }
export { OssUploader }
export { Cropper }
export { HelloWorld }
export { CodePreview }
export { ImagePreview }
export { PdfPreview }
export { VideoPreview }
export { ParseUrl }
export { ValidityChecker }
export { HyUpload }
export { WebEnv }
export default {
  version,
  install,
  HelloWorld,
  NosUploader,
  OssUploader,
  Cropper,
  CodePreview,
  ImagePreview,
  PdfPreview,
  VideoPreview,
  ParseUrl,
  ValidityChecker,
  HyUpload,
  WebEnv
}
