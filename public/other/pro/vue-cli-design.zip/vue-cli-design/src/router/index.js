import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import nosUploader from '../views/uploader/nosUploader.vue'
import ossUploader from '../views/uploader/ossUploader.vue'
import cropper from '../views/cropper.vue'
import CodePreview from '../views/codePreview'
import ImagePreview from '../views/imagePreview'
import PdfPreview from '../views/pdfPreview'
import VideoPreview from '../views/videoPreview'
import ParseUrl from '../views/parseUrl'
import ValidityChecker from '../views/validityChecker'
import HyUpload from '../views/hyUpload'
import webEnv from '../views/webEnv'
Vue.use(VueRouter)
const routes = [{
  path: '/',
  name: 'Home',
  component: Home
}, {
  path: '/about',
  name: 'About',
  // route level code-splitting
  // this generates a separate chunk (about.[hash].js) for this route
  // which is lazy-loaded when the route is visited.
  component: () => import(
  /* webpackChunkName: "about" */
    '../views/About.vue')
}, {
  path: '/cropper',
  name: 'cropper',
  // component: () => import('@/views/TheCropper.vue')
  component: cropper
}, {
  path: '/uploader/nosUploader',
  name: 'nosUploader',
  component: nosUploader
}, {
  path: '/uploader/ossUploader',
  name: 'ossUploader',
  component: ossUploader
}, {
  path: '/CodePreview',
  name: 'CodePreview',
  component: CodePreview
}, {
  path: '/ImagePreview',
  name: 'ImagePreview',
  component: ImagePreview
}, {
  path: '/PdfPreview',
  name: 'PdfPreview',
  component: PdfPreview
}, {
  path: '/VideoPreview',
  name: 'VideoPreview',
  component: VideoPreview
}, {
  path: '/ParseUrl',
  name: 'ParseUrl',
  component: ParseUrl
}, {
  path: '/ValidityChecker',
  name: 'ValidityChecker',
  component: ValidityChecker
}, {
  path: '/HyUpload',
  name: 'HyUpload',
  component: HyUpload
}, {
  path: '/webEnv',
  name: 'WebEnv',
  component: webEnv
}]
const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
  scrollBehavior: () => {
    return { y: 0 }
  }
})
export default router
