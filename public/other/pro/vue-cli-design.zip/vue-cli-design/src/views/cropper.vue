<template>
  <div :class="$style['container']">
    <div
      :class="$style['content']"
    >
      <img
        v-show="!isCropper"
        ref="img"
        :class="$style['layer-img']"
        :src="cData.img || cData.url"
        alt=""
        :style="{
          width: `${imgPos.width}px`,
          height: `${imgPos.height}px`,
          left: `${imgPos.left}px`,
          top: `${imgPos.top}px`,
        }"
        @dblclick="cropperMedia"
      >
      <!-- </div> -->
    </div>
    <Cropper
      v-if="isCropper"
      ref="myCropper"
      :data="cData"
      @submit="submit"
      @action="action"
    />
  </div>
</template>

<script>
// import Cropper from '../../packages/cropper/src/BaseCropper.vue'
import { Cropper } from '../index'
import KAOLA from '@/assets/img/Koala.jpg'
// const KAOLA = 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fpic.jj20.com%2Fup%2Fallimg%2F1111%2F0Q91Q50307%2F1PQ9150307-8.jpg&refer=http%3A%2F%2Fpic.jj20.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1644918616&t=168b39a77cfa14e6af64f7a3f8912605'
// const KAOLA = 'https://nos-creative-video-test.nos-jd.163yun.com/2022011115022581dee70209ef4f4c98328216928e773b.png?download=15022581dee70209ef4f4c98328216928e773b.png&Signature=hCvctt0zSlbD4slmwZsT74%2BKjv3Xo7PRHBUiP8BK4%2FY%3D&Expires=4105148546&NOSAccessKeyId=a2b368da8d27405fbe0e771bf7ab2cf9'

export default {
  name: 'DemoCropper',
  components: {
    Cropper,
  },
  data () {
    return {
      // 图片位置
      firstCropper: true,
      imgPos: {
        width: 256,
        height: 192,
        left: 50,
        top: 50,
      },
      cData: {
        url: KAOLA, // 必需，待裁剪图片url
        cropImage: true, // 退出裁剪状态时仅返回坐标信息，不返回裁剪后的img对象
        img: '', // cropImage为false时不返回该值
        targetbox: { // 必需，承载图片的dom BoundingClientRect
          left: 0,
          top: 0,
          width: 0,
          height: 0,
        },
        innerbox: { // 必需，裁剪内框，坐标相较于父级relative/absolute布局dom
          left: 0,
          top: 0,
          width: 0,
          height: 0,
        },
        outterbox: { // 必需，裁剪外框, 坐标相较于内框
          left: 0,
          top: 0,
          width: 0,
          height: 0,
        },
        // containerbox: { // 选填，填入后最终返回的图片取得是inner和outter已经自己三者之间的交集
        //   left: 0,
        //   top: 0,
        //   width: 400,
        //   height: 300,
        // },
      },
      isCropper: false,
    }
  },
  created () {
    this.test()
    // const viewPosition = this.cData.view
    // viewPosition.width = viewPosition.windowWidth + 200
    // viewPosition.height = viewPosition.windowHeight + 200 * 200 / 266
  },
  methods: {
    cropperMedia () {
      const { width, height, left, top } = this.$refs.img.getBoundingClientRect()
      Object.assign(this.cData.targetbox, { width, height, left, top })
      if (this.firstCropper) {
        this.firstCropper = false
        Object.assign(this.cData.innerbox, this.imgPos)
        Object.assign(this.cData.outterbox, this.imgPos, {
          left: 0,
          top: 0,
        })
      }
      this.isCropper = true
    },
    getImgStyle (media) {
      return {
        width: `${media.width}px`,
        height: `${media.height}px`,
        left: `${media.left}px`,
        top: `${media.top}px`,
      }
    },
    submit (data) {
      // 裁剪完成
      // data {
      //   url: '原始图片url',
      //   img: '裁剪后的base64图片',
      //   innerbox,
      //   outterbox,
      //   targetbox,
      // }
      this.isCropper = false
      Object.assign(this.cData, data)
      Object.assign(this.imgPos, data.innerbox)
      console.log('complete', data)
    },
    cancel (data) {
      // 取消裁剪
      this.isCropper = false
      Object.assign(this.cData, data)
      Object.assign(this.imgPos, data.innerbox)
      console.log('cancel', data)
    },
    action () {
      // 点击裁剪灰幕后触发，表示已退出裁剪，
      // 此时组件还在进行裁剪的数据操作，
      // 使用时可酌情考虑增加loading
      console.log('loading')
    },
    test () {
      // setInterval(() => {
      //   // 取消：返回上一次进入裁剪时的入参
      //   this.$refs.myCropper.cancel().then((result) => {
      //     this.cancel(result)
      //   })
      //   // 提交：返回裁剪后的数据
      //   this.$refs.myCropper.submit().then((result) => {
      //     this.submit(result)
      //   })
      // }, 5000)
    }
  },
}
</script>

<style lang="less" module>
.container {
  position: relative;
  min-width: 400px;
  min-height: 350px;
  .content {
    outline: 1px solid #dddddd;
    position: absolute;
    // overflow: hidden;
    width: 400px;
    height: 300px;
    left: 100px;
    top: 50px;
    .layer-img {
      position: absolute;
    }
  }
}
</style>
