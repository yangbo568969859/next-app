<template>
  <div class="g-hy-upload">
    <h1>HyUpload</h1>
    <hy-upload
      ref="uuu"
      :accept="'.mp4,.mov'"
      :limit="8*1024"
      :is-multiple="true"
      :length="10"
      :upload-params="{
        code: 'creative_ps_saas'
      }"
    />
    <a-button @click="click">
      获取结果
    </a-button>
  </div>
</template>

<script>
// import HyUpload from '../../packages/hyUpload/src/main.vue'
import { Button } from 'ant-design-vue'
import { HyUpload } from '../index'

export default {
  name: 'DemoHyUpload',
  components: {
    [Button.name]: Button,
    HyUpload,
  },
  methods: {
    click () {
      this.$refs.uuu.getList().then((filelist) => {
        console.log('fileList', filelist)
      })
    },
    success (msg) {
      console.log('success', msg)
    }
  }
}
</script>

<style lang="less" scoped>
.g-hy-upload {
  margin-left: 16px;
}
</style>
