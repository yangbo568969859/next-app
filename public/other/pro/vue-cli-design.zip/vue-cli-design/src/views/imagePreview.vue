<template>
  <div>
    <h1>ImagePreview</h1>
    <image-preview :theme="theme"  v-model="visible" :src="imageSrc" />
    <button @click="showPreview">light theme</button>
    <button @click="showPreview('dark')">dark theme</button>
  </div>
</template>

<script>
import { ImagePreview } from '../index'

export default {
  name: 'DemoImagePreview',
  components: {
    ImagePreview,
  },
  data () {
    return {
      theme: 'dark',
      visible: false,
      imageSrc: 'https://img6.bdstatic.com/img/image/pcindex/sunjunpchuazhoutu.JPG',
    }
  },
  methods: {
    showPreview (theme) {
      this.theme = theme
      this.visible = true
    }
  }
}
</script>
