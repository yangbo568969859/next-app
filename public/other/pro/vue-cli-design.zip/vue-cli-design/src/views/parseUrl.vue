<template>
  <div v-if="url">
    <h2>{{ url.source }}</h2>
    <h1>{{ url.protocol }}</h1>
    <h1>{{ url.host }}</h1>
    <h1>{{ url.hash }}</h1>
    <h1>{{ url.params }}</h1>
    <h1>{{ url.segments }}</h1>
  </div>
</template>

<script>
import { ParseUrl } from '../index'

// 测试方法
ParseUrl()

export default {
  name: 'DemoParseUrl',
  data () {
    return {
      url: null
    }
  },
  mounted () {
    this.init()
  },
  methods: {
    init () {
      this.url = ParseUrl('http://test.163yun.com:8081/admin/#/courseCenter/courseList/info?id=6195334607360000')
    }
  }
}
</script>
