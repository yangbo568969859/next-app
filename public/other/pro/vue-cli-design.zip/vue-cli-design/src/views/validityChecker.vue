<template>
  <div>
    <h1>ValidityChecker</h1>
  </div>
</template>

<script>
import { ValidityChecker } from '../index'

// 测试方法
ValidityChecker({ type: 'email', value: 'xxx.com' })
// console.log(ValidityChecker({ type: 'email', value: 'xxx@com' }))
// console.log(ValidityChecker({ type: 'email', value: 'xulizhi@crop.netease.com' }))
// console.log(ValidityChecker({ type: 'phone', value: '12345678000' }))
// console.log(ValidityChecker({ type: 'phone', value: '13814683288' }))

export default {
  name: 'DemoValidityChecker'
}
</script>
