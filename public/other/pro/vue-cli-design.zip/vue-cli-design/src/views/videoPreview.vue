<template>
  <div>
    <h1>VideoPreview</h1>
    <video-preview v-model="visible" src="https://mini.nos-jd.163yun.com/202203081123659489102433202177_creative_ps_saas_Project_WebGL_to_Video.mp4?fileName=Project_WebGL_to_Video.mp4&Signature=sXanA8rykNcheg79OxMwqj4N%2FAe%2B428aPyrX7VbltrE%3D&Expires=4802342400&NOSAccessKeyId=a2b368da8d27405fbe0e771bf7ab2cf9" />
    <button @click="showPreview">show</button>
  </div>
</template>

<script>
import { VideoPreview } from '../index'

export default {
  name: 'DemoVideoPreview',
  components: {
    VideoPreview,
  },
  data () {
    return {
      visible: false
    }
  },
  methods: {
    showPreview () {
      this.visible = true
    }
  }
}
</script>
