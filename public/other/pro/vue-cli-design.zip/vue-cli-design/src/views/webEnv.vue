<template>
  <div class="env-demo">
    <div class="env-header">
      USER-AGENT PLAYGROUND
    </div>
    <div class="env-segment">
      <div class="row">
        <div
          v-if="browser"
          class="column"
        >
          <div class="type">
            Browser
          </div>
          <div class="value">
            <span>{{ browser.name }}</span>
            <span>{{ browser.version }}</span>
            <span>{{ browser.major }}</span>
          </div>
        </div>
        <div
          v-if="engine"
          class="column"
        >
          <div class="type">
            Engine
          </div>
          <div class="value">
            <span>{{ engine.name || '-' }}</span>
          </div>
        </div>
        <div
          v-if="os"
          class="column"
        >
          <div class="type">
            OS
          </div>
          <div class="value">
            <span>{{ os.name }}</span>
            <span>{{ os.version || '-' }}</span>
          </div>
        </div>
        <div
          v-if="network"
          class="column"
        >
          <div class="type">
            NETWORK
          </div>
          <div class="value">
            <span>{{ network }}</span>
          </div>
        </div>
        <div
          class="column"
        >
          <div class="type">
            Type
          </div>
          <div class="value">
            <span>{{ device || '-' }}</span>
          </div>
        </div>
        <div
          class="column"
        >
          <div class="type">
            isWeixin
          </div>
          <div class="value">
            <span>{{ isWeixin }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="env-select">
      <select
        class="select"
        name=""
        @change="selectChange"
      >
        <option
          v-for="(ua, index) in userAgents"
          :key="index"
          :value="ua"
          class="option"
        >
          {{ ua }}
        </option>
      </select>
    </div>
    <div class="env-input">
      <div class="env-input-text">
        <input
          v-model="uaValue"
          type="text"
          class="input"
        >
      </div>
      <div class="env-input-button">
        <button
          class="button"
          @click="testUA"
        >
          测试
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { WebEnv } from '../index'

const userAgents = [
  'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB5; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36', // chrome
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5015.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36 Edg/100.0.1185.39',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0',

  'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (iPad; CPU OS 13_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/87.0.4280.77 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1 wechatdevtools/1.05.2108130 MicroMessenger/8.0.5 Language/zh_CN webview/16505388630739341 webdebugger port/28037 token/612c1c46237e22ef8a1199c121f86b39'
]

export default {
  name: 'DemoWebEnv',
  data () {
    return {
      uaValue: '',
      userAgents,
      browser: null,
      engine: null,
      os: null,
      network: null,
      fingerPrint: null,
      device: null,
      isWeixin: false
    }
  },
  mounted () {
    this.getWebEnv(userAgents[0])
  },
  methods: {
    getWebEnv (userAgent) {
      // Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1 wechatdevtools/1.05.2108130 MicroMessenger/8.0.5 Language/zh_CN webview/16450045649469045 webdebugger port/19981 token/2c3059c9e67200d903dfb525e70999ed
      // 测试方法
      const ua = WebEnv(userAgent)
      this.browser = ua.getBrowser()
      this.engine = ua.getEngine()
      this.os = ua.getOS()
      this.device = ua.getDevice()
      this.isWeixin = ua.isWeixin
    },
    selectChange (e) {
      this.getWebEnv(e.target.value)
    },
    testUA () {
      this.getWebEnv(this.uaValue)
    }
  }
}
</script>

<style lang="less">
.env-demo {
  padding: 20px;
}
.env-segment {
  position: relative;
  background: #FFFFFF;
  box-shadow: 0 1px 10px rgb(223, 227, 239, 0.5);
  margin: 1rem 0em;
  padding: 1em 1em;
  border-radius: 0.28571429rem;
  border: 1px solid rgba(34, 36, 38, 0.15);
  .row {
    display: flex;
    // max-width: ;
    .column {
      display: flex;
      flex-direction: column;
      padding: 14px;
      box-shadow: -1px 0px 0px 0px #d4d4d5;
      &:first-child {
        box-shadow: none;
      }
      .type {
        text-align: left;
      }
      .value {
        margin-top: 20px;
        span {
          display: inline-block;
          line-height: 1;
          vertical-align: baseline;
          margin: 0em 2px;
          background-color: #E8E8E8;
          background-image: none;
          padding: 8px 11px;
          color: rgba(0, 0, 0, 0.6);
          text-transform: none;
          font-weight: bold;
          border: 0px solid transparent;
          border-radius: 4px;
          -webkit-transition: background 0.1s ease;
          transition: background 0.1s ease;
        }
      }
    }
  }
}
.env-select {
  width: 100%;
  margin-bottom: 20px;
  .select {
    width: 100%;
    height: 30px;
  }
  .option {
    width: 100%;
  }
}
.env-input {
  display: flex;
  &-text {
    .input {
      width: 400px;
      height: 27px;
      margin-right: 10px;
    }
  }
  &-button {
    .button {
      height: 26px;
    }
  }
}
</style>
