export const browsers = [
  {
    desc: 'Chrome Browser on PC',
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36',
    expect: {
      name: 'Chrome',
      version: '100.0.4896.88',
    },
  },
  {
    desc: 'Microsoft Edge 0.1',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0',
    expect: {
      name: 'Edge',
      version: '12.0',
    },
  },
  {
    desc: 'Firefox',
    ua: 'Mozilla/5.0 (Windows NT 6.1; rv:15.0) Gecko/20120716 Firefox/15.0a2',
    expect: {
      name: 'Firefox',
      version: '15.0a2',
    },
  },
  {
    desc: 'Firefox',
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:100.0) Gecko/20100101 Firefox/100.0',
    expect: {
      name: 'Firefox',
      version: '100.0',
    },
  },
  {
    desc: 'Firefox Focus',
    ua: 'Mozilla/5.0 (Linux; Android 7.0) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Focus/6.1.1 Chrome/68.0.3440.91 Mobile Safari/537.36',
    expect: {
      name: 'Firefox Focus',
      version: '6.1.1',
    },
  },
  {
    desc: 'Chromium',
    ua: 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.7 (KHTML, like Gecko) Ubuntu/11.10 Chromium/16.0.912.21 Chrome/16.0.912.21 Safari/535.7',
    expect: {
      name: 'Chromium',
      version: '16.0.912.21',
    },
  },
  {
    desc: 'Opera',
    ua: 'Opera/9.80 (X11; Linux x86_64; U; Linux Mint; en) Presto/2.2.15 Version/10.10',
    expect: {
      name: 'Opera',
      version: '10.10',
    },
  },
  {
    desc: 'Opera Mini',
    ua: 'Opera/9.80 (J2ME/MIDP; Opera Mini/5.1.21214/19.916; U; en) Presto/2.5.25',
    expect: {
      name: 'Opera Mini',
      version: '5.1.21214',
      major: '5',
    },
  },
  {
    desc: 'Opera Mini 8 above on iPhone',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) OPiOS/12.1.1.98980 Mobile/13C75 Safari/9537.53',
    expect: {
      name: 'Opera Mini',
      version: '12.1.1.98980',
      major: '12',
    },
  },
  {
    desc: 'Opera Tablet',
    ua: 'Opera/9.80 (Windows NT 6.1; Opera Tablet/15165; U; en) Presto/2.8.149 Version/11.1',
    expect: {
      name: 'Opera Tablet',
      version: '11.1',
      major: '11',
    },
  },
  {
    desc: 'Opera Coast',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X; en) AppleWebKit/601.1.46 (KHTML, like Gecko) Coast/5.04.110603 Mobile/13F69 Safari/7534.48.3',
    expect: {
      name: 'Opera Coast',
      version: '5.04.110603',
      major: '5',
    },
  },
  {
    desc: 'Vivaldi',
    ua: 'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.89 Vivaldi/1.0.83.38 Safari/537.36',
    expect: {
      name: 'Vivaldi',
      version: '1.0.83.38',
    },
  },
  {
    desc: 'Yandex',
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.5 (KHTML, like Gecko) YaBrowser/1.0.1084.5402 Chrome/19.0.1084.5402 Safari/536.5',
    expect: {
      name: 'Yandex',
      version: '1.0.1084.5402'
    }
  },
  {
    desc: 'Arora',
    ua: 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de-CH) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2',
    expect: {
      name: 'Arora',
      version: '0.2',
      major: '0'
    }
  },
  {
    desc: 'Lunascape',
    ua: 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.2) Gecko/20090804 Firefox/3.5.2 Lunascape/5.1.4.5',
    expect: {
      name: 'Lunascape',
      version: '5.1.4.5'
    }
  },
  {
    desc: 'QupZilla',
    ua: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/538.1 (KHTML, like Gecko) QupZilla/1.8.9 Safari/538.1',
    expect: {
      name: 'QupZilla',
      version: '1.8.9'
    }
  },
  {
    desc: 'QQ',
    ua: 'Mozilla/5.0 (Linux; U; Android 4.4.4; zh-cn; OPPO R7s Build/KTU84P) AppleWebKit/537.36 (KHTML, like Gecko)Version/4.0 Chrome/37.0.0.0 MQQBrowser/7.1 Mobile Safari/537.36',
    expect: {
      name: 'QQBrowser',
      version: '7.1',
    },
  },
  {
    desc: 'QQ on iOS',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_0_2 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Mobile/14A456 QQ/6.5.3.410 V1_IPH_SQ_6.5.3_1_APP_A Pixel/1080 Core/UIWebView NetType/WIFI Mem/26',
    expect: {
      name: 'QQ',
      version: '6.5.3.410',
    },
  },
  {
    desc: 'UC Browser',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 UBrowser/5.6.12860.7 Safari/537.36',
    expect: {
      name: 'UCBrowser',
      version: '5.6.12860.7',
    },
  },
  {
    desc: 'Sogou Browser',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.221 Safari/537.36 SE 2.X MetaSr 1.0',
    expect:
      {
        name: 'Sogou',
        version: '2.X'
      }
  },
  {
    desc: 'MIUI Browser on Xiaomi Hongmi WCDMA (HM2013023)',
    ua: 'Mozilla/5.0 (Linux; U; Android 4.2.2; ru-ru; 2013023 Build/HM2013023) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30 XiaoMi/MiuiBrowser/1.0',
    expect: {
      name: 'MiuiBrowser',
      version: '1.0',
    },
  },
  {
    desc: 'Wechat',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1 wechatdevtools/1.05.2108130 MicroMessenger/8.0.5 Language/zh_CN webview/16505388630739341 webdebugger port/28037 token/612c1c46237e22ef8a1199c121f86b39',
    expect: {
      name: 'Wechat',
      version: '8.0.5',
    },
  },
  {
    desc: 'WechatWork Windows',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 wxwork/2.1.3 (MicroMessenger/6.2) WindowsWechat QBCore/3.43.644.400 QQBrowser/9.0.2524.400',
    expect: {
      name: 'WechatWork',
      version: '2.1.3',
    },
  },
  {
    desc: 'Weibo',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/16A366 Weibo (iPhone8,2__weibo__8.9.3__iphone__os12.0)',
    expect: {
      name: 'Weibo',
      version: '8.9.3',
    },
  },
  {
    desc: '2345 Browser',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.90 Safari/537.36 2345Explorer/9.2.1.17116',
    expect: {
      name: '2345Explorer',
      version: '9.2.1.17116'
    }
  },
  {
    desc: 'IE11 on Windows 7',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64; APCPMS=^N201205020840572565478A37A6F9C41BD33F_9975^; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E; MARKANYEPS#25118; Zoom 3.6.0; rv:11.0) like Gecko',
    expect: {
      name: 'IE',
      version: '11.0',
    },
  },
  {
    desc: 'Safari',
    ua: 'Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/533.17.8 (KHTML, like Gecko) Version/5.0.1 Safari/533.17.8',
    expect: {
      name: 'Safari',
      version: '5.0.1',
    },
  },
  {
    desc: 'Coc Coc Browser',
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/78.0.129 Chrome/72.0.3626.129 Safari/537.36',
    expect: {
      name: 'Coc Coc',
      version: '78.0.129',
    },
  },
  {
    desc: 'QupZilla',
    ua: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/538.1 (KHTML, like Gecko) QupZilla/1.8.9 Safari/538.1',
    expect: {
      name: 'QupZilla',
      version: '1.8.9',
    },
  },
  {
    desc: 'Kindle Browser',
    ua: 'Mozilla/4.0 (compatible; Linux 2.6.22) NetFront/3.4 Kindle/2.5 (screen 600x800; rotate)',
    expect: {
      name: 'Kindle',
      version: '2.5',
    },
  },
  {
    desc: 'Iceweasel',
    ua: 'Mozilla/5.0 (X11; U; Linux i686; de; rv:1.9.0.16) Gecko/2009121610 Iceweasel/3.0.6 (Debian-3.0.6-3)',
    expect: {
      name: 'Iceweasel',
      version: '3.0.6',
    },
  },
  {
    desc: 'Konqueror',
    ua: 'Mozilla/5.0 (compatible; Konqueror/3.5; Linux; X11; x86_64) KHTML/3.5.6 (like Gecko) (Kubuntu)',
    expect: {
      name: 'Konqueror',
      version: '3.5',
    },
  },
  {
    desc: 'IceApe',
    ua: 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.19) Gecko/20110817 Iceape/2.0.14',
    expect: {
      name: 'Iceape',
      version: '2.0.14',
    },
  },
  {
    desc: 'SeaMonkey',
    ua: 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1b4pre) Gecko/20090405 SeaMonkey/2.0b1pre',
    expect: {
      name: 'SeaMonkey',
      version: '2.0b1pre',
    },
  },
  {
    desc: 'Epiphany',
    ua: 'Mozilla/5.0 (X11; U; FreeBSD i386; en-US; rv:1.7) Gecko/20040628 Epiphany/1.2.6',
    expect: {
      name: 'Epiphany',
      version: '1.2.6',
    },
  },
  {
    desc: 'Baidu',
    ua: 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; baidubrowser 1.x)',
    expect: {
      name: 'Baidu',
      version: '1.x',
    },
  },
  {
    desc: '360',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_4_1 like Mac OS X) AppleWebKit/607.3.9 (KHTML, like Gecko) Mobile/16G102 QHBrowser/317 QihooBrowser/4.0.10',
    expect: {
      name: '360',
      version: '4.0.10',
    },
  },
  {
    desc: '360EE',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 QIHU 360EE',
    expect: {
      name: '360EE',
      version: '',
    },
  },
  {
    desc: '360SE',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 QIHU 360SE',
    expect: {
      name: '360SE',
      version: '',
    },
  },
  {
    desc: 'LBBROWSER',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.154 Safari/537.36 LBBROWSER',
    expect: {
      name: 'LBBROWSER',
      version: '5.3',
    },
  },
  {
    desc: 'LBBROWSER',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2311.154 Safari/537.36 LBBROWSER',
    expect: {
      name: 'LBBROWSER',
      version: '',
    },
  },
  {
    desc: 'LBBROWSER LieBaoFast',
    ua: 'Mozilla/5.0 (Linux; Android 10; MOA-AL00 Build/HONORMOA-AL00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36 LieBaoFast/5.26.0',
    expect: {
      name: 'LBBROWSER',
      version: '5.26.0',
    },
  }
]

export const engines = [
  {
    desc: 'Trident',
    ua: 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Win64; x64; Trident/6.0)',
    expect: {
      name: 'Trident',
    },
  },
  {
    desc: 'WebKit',
    ua: 'Mozilla/5.0 (Windows; U; Windows NT 6.1; sv-SE) AppleWebKit/533.19.4 (KHTML, like Gecko) Version/5.0.3 Safari/533.19.4',
    expect: {
      name: 'WebKit',
    },
  },
  {
    desc: 'Blink',
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36',
    expect: {
      name: 'Blink',
    },
  },
  {
    desc: 'WebKit',
    ua: 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/27.0.1453.110 Safari/537.36',
    expect: {
      name: 'WebKit',
    },
  },
  {
    desc: 'Gecko',
    ua: 'Mozilla/5.0 (X11; Linux x86_64; rv:2.0b9pre) Gecko/20110111 Firefox/4.0b9pre',
    expect: {
      name: 'Gecko'
    },
  },
  {
    desc: 'Presto',
    ua: 'Opera/9.80 (Windows NT 6.1; Opera Tablet/15165; U; en) Presto/2.8.149 Version/11.1',
    expect: {
      name: 'Presto'
    },
  },
  {
    desc: 'Opera > 12',
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36 OPR/85.0.4341.47',
    expect: {
      name: 'Blink'
    },
  },
  {
    desc: 'Yandex',
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.5 (KHTML, like Gecko) YaBrowser/1.0.1084.5402 Chrome/19.0.1084.5402 Safari/536.5',
    expect: {
      name: 'Blink'
    },
  },
  {
    desc: 'Blink',
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    expect: {
      name: 'Blink',
    },
  },
  {
    desc: 'EdgeHTML',
    ua: 'Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36 Edge/12.0',
    expect: {
      name: 'EdgeHTML',
    },
  },
  {
    desc: 'Edge Blink',
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36 Edg/101.0.1210.32',
    expect: {
      name: 'Blink',
    },
  }
]

export const osList = [
  {
    desc: 'Windows 10.0',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0',
    expect: {
      name: 'Windows',
      version: '10.0',
    },
  },
  {
    desc: 'Windows XP',
    ua: 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB5; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
    expect: {
      name: 'Windows',
      version: 'XP',
    },
  },
  {
    desc: 'Android',
    ua: 'Mozilla/5.0 (Linux; U; Android 2.2.2; en-us; VM670 Build/FRG83G) AppleWebKit/533.1 (KHTML, like Gecko)',
    expect: {
      name: 'Android',
      version: '2.2.2',
    },
  },
  {
    desc: 'iOS',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1 wechatdevtools/1.05.2108130 MicroMessenger/8.0.5 Language/zh_CN webview/16505388630739341 webdebugger port/28037 token/612c1c46237e22ef8a1199c121f86b39',
    expect: {
      name: 'iOS',
      version: '11.0',
    },
  },
  {
    desc: 'Debian',
    ua: 'Mozilla/5.0 (X11; Linux x86_64; Debian GNU/Linux 8.1 (jessie)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.0 Maxthon/1.0.5.3 Safari/537.36',
    expect: {
      name: 'Debian',
      version: '8.1',
    },
  },
  {
    desc: 'Windows Phone 8',
    ua: 'Mozilla/5.0 (compatible; MSIE 10.0; Windows Phone 8.0; Trident/6.0; IEMobile/10.0; ARM; Touch; HTC; Windows Phone 8X by HTC)',
    expect: {
      name: 'Windows Phone',
      version: '8.0',
    },
  },
  {
    desc: 'Mac OS',
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36',
    expect: {
      name: 'Mac OS',
      version: '10.6.8',
    },
  },
  {
    desc: 'WebOS',
    ua: 'Mozilla/5.0 (hp-tablet; Linux; hpwOS/3.0.5; U; en-US) AppleWebKit/534.6 (KHTML, like Gecko) wOSBrowser/234.83 Safari/534.6 TouchPad/1.0',
    expect: {
      name: 'WebOS',
      version: '3.0.5',
    },
  },
  {
    desc: 'Symbian',
    ua: 'Nokia5250/10.0.011 (SymbianOS/9.4; U; Series60/5.0 Mozilla/5.0; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/525 (KHTML, like Gecko) Safari/525 3gpp-gba',
    expect: {
      name: 'Symbian',
      version: '9.4',
    },
  }
  // {
  //   desc: 'Linux',
  //   ua: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
  //   expect: {
  //     name: 'Linux',
  //     version: 'x86_64',
  //   },
  // },
  // {
  //   desc: 'Ubuntu',
  //   ua: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.22+ (KHTML, like Gecko) Chromium/17.0.963.56 Chrome/17.0.963.56 Safari/535.22+ Ubuntu/12.04 (3.4.1-0ubuntu1) Epiphany/3.4.1',
  //   expect: {
  //     name: 'Ubuntu',
  //     version: '12.04',
  //   },
  // },
]

export const uaTypes = [
  {
    desc: 'Windows 10.0',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0',
    expect: '',
  },
  {
    desc: 'Windows XP',
    ua: 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB5; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
    expect: '',
  },
  {
    desc: 'iOS',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1 wechatdevtools/1.05.2108130 MicroMessenger/8.0.5 Language/zh_CN webview/16505388630739341 webdebugger port/28037 token/612c1c46237e22ef8a1199c121f86b39',
    expect: 'Mobile',
  },
  {
    desc: 'iPad using UCBrowser',
    ua: 'Mozilla/5.0 (iPad; U; CPU OS 11_2 like Mac OS X; zh-CN; iPad5,3) AppleWebKit/534.46 (KHTML, like Gecko) UCBrowser/3.0.1.776 U3/ Mobile/10A403 Safari/7543.48.3',
    expect: 'iPad'
  },
  {
    desc: 'iPad Air',
    ua: 'Mozilla/5.0 (iPad; CPU OS 12_4_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBDV/iPad4,1;FBMD/iPad;FBSN/iOS;FBSV/12.4.5;FBSS/2;FBID/tablet;FBLC/en_US;FBOP/5;FBCR/]',
    expect: 'iPad'
  },
  {
    desc: 'Tablet',
    ua: 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 7 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.99 Safari/537.36',
    expect: 'Tablet'
  }
]

export const weiXinList = [
  {
    desc: 'weixin false',
    ua: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0',
    expect: false,
  },
  {
    desc: 'weixin false',
    ua: 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB5; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
    expect: false,
  },
  {
    desc: 'weixin true',
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1 wechatdevtools/1.05.2108130 MicroMessenger/8.0.5 Language/zh_CN webview/16505388630739341 webdebugger port/28037 token/612c1c46237e22ef8a1199c121f86b39',
    expect: true,
  },
]
