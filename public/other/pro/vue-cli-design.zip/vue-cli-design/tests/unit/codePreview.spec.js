// import CodePreview from '../../packages/CodePreview'

describe('CodePreview', () => {
  it('CodePreview test', () => {
    expect(true).toBe(true)
  })
})
