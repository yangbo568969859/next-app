// import HyUpload from '../../packages/HyUpload'

describe('HyUpload', () => {
  it('HyUpload test', () => {
    expect(true).toBe(true)
  })
})
