// import ImagePreview from '../../packages/ImagePreview'

describe('ImagePreview', () => {
  it('ImagePreview test', () => {
    expect(true).toBe(true)
  })
})
