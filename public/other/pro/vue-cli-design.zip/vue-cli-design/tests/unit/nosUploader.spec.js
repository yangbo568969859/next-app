import nosUploader from '../../packages/nosUploader'

describe('nosUploader', () => {
  it('nosUploader test', () => {
    expect(!!nosUploader).toBe(true)
  })
})
