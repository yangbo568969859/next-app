import ParseUrl from '../../packages/ParseUrl'

describe('ParseUrl', () => {
  it('ParseUrl test', () => {
    const result = {
      source: 'http://test.163yun.com:8081/admin/#/courseCenter/courseList/info?id=6195334607360000',
      protocol: 'http',
      host: 'test.163yun.com',
      port: '8081',
      query: '',
      params: {
        id: '6195334607360000'
      },
      hash: '/courseCenter/courseList/info?id=6195334607360000',
      segments: [
        'admin',
        ''
      ]
    }
    expect(ParseUrl('http://test.163yun.com:8081/admin/#/courseCenter/courseList/info?id=6195334607360000')).toEqual(result)
  })
})
