// import PdfPreview from '../../packages/PdfPreview'

describe('PdfPreview', () => {
  it('PdfPreview test', () => {
    expect(true).toBe(true)
  })
})
