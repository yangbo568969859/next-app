import ValidityChecker from '../../packages/ValidityChecker'

describe('ValidityChecker', () => {
  it('ValidityChecker test', () => {
    expect(ValidityChecker({ type: 'email', value: 'xxx@com' })).toBe(false)
    expect(ValidityChecker({ type: 'email', value: 'xulizhi@crop.netease.com' })).toBe(true)
    expect(ValidityChecker({ type: 'phone', value: '12345678000' })).toBe(false)
    expect(ValidityChecker({ type: 'phone', value: '13814683288' })).toBe(true)
    expect(ValidityChecker({ type: 'email', value: '1.1.1.1' })).toBe(false)
    expect(() => ValidityChecker()).toThrow('校验类型与内容不能为空')
    expect(() => ValidityChecker({ type: '', value: '1.1.1.1' })).toThrow('校验类型与内容不能为空')
    expect(ValidityChecker({ type: 'email', value: '1.1.1.1' })).toBe(false)
    expect(ValidityChecker({ type: 'email', value: '0' })).toBe(false)
    expect(() => ValidityChecker({ type: 'ip', value: '13814683288' })).toThrow('校验类型错误')
  })
})
