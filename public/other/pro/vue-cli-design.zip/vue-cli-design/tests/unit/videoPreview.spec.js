// import VideoPreview from '../../packages/VideoPreview'

describe('VideoPreview', () => {
  it('VideoPreview test', () => {
    expect(true).toBe(true)
  })
})
