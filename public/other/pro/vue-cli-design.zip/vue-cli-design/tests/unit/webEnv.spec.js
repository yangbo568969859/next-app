import WebEnv from '../../packages/webEnv/index'
import {
  browsers,
  engines,
  osList,
  uaTypes,
  weiXinList
} from '../json/webenv-test'

const methods = [
  {
    title: 'getBrowser',
    label: 'browser',
    list: browsers,
    properties: ['name', 'version']
  },
  {
    title: 'getEngine',
    label: 'engine',
    list: engines,
    properties: ['name']
  },
  {
    title: 'getOS',
    label: 'os',
    list: osList,
    properties: ['name', 'version']
  },
  {
    title: 'getType',
    label: 'device',
    list: uaTypes,
    properties: null
  },
  {
    title: 'isWeixin',
    label: 'isWeixin',
    list: weiXinList,
    properties: null
  }
]

for (const m in methods) {
  const mvalue = methods[m]
  describe(mvalue.title, () => {
    for (const i in mvalue.list) {
      if (mvalue.list[i].ua) {
        describe('[' + mvalue.list[i].desc + ']', () => {
          describe(`"${mvalue.list[i].ua}"`, () => {
            const uaParser = WebEnv(mvalue.list[i].ua)
            const expectRes = mvalue.list[i].expect
            const result = uaParser.getResult()[mvalue.label]
            if (Array.isArray(mvalue.properties)) {
              mvalue.properties.forEach((props) => {
                it(`should return ${mvalue.label} ${props}: ${expectRes[props]}`, function () {
                  expect(result[props]).toBe(expectRes[props])
                })
              })
            } else {
              it(`should return userAgent type: ${expectRes}`, function () {
                expect(result).toBe(expectRes)
              })
            }
          })
        })
      }
    }
  })
}

describe('WebEnv No Params', () => {
  Object.defineProperty(window.navigator, 'userAgent', { value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36' })
  const uaParser = WebEnv()
  const result = uaParser.getResult()
  const testRes = {
    browser: { name: 'Chrome', version: '100.0.4896.127', major: '100' },
    engine: { name: 'Blink' },
    os: { name: 'Windows', version: '10.0' },
    device: '',
    isWeixin: false
  }
  expect(result).toEqual(testRes)
})
