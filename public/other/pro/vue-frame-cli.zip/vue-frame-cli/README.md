# @di/netease-hy-cli

杭研数字产业技术部专用CLI

## 描述
@di/netease-hy-cli是杭研数字产业技术部内部cli，可以帮助开发者初始化项目工程，同步产品架构。

## 安装
```
npm install -g @di/netease-hy-cli -S --registry http://rnpm.hz.netease.com/
```

## 使用
@di/netease-hy-cli为全局安装的cli工具

### 查看帮助
```
➜ hy-cli -h
Usage: hy-cli [options]

Options:
  -V, --version                    output the version number
  --create [type: business | npm]  新建业务/npm工程
  --init [type: business | npm]    初始化业务/npm工程
  --dev                            启动dev服务(敬请期待)
  --local                          启动local服务(敬请期待)
  --build                          build项目(敬请期待)
  -c, --config [path]              set webpack configuration file to override the built-in
                                   configuration(敬请期待)
  -h, --help                       display help for command
```

### 创建项目
若还没有为业务新建文件夹，则使用create初始化工程.  
依次输入如下信息：  
* 文件夹名称
* 项目类型
* 中文名称（可直接回车跳过，默认：网易数字产业平台（业务）/ 网易数字产业平台NPM库（npm工程））
* 英文名称（可直接回车跳过，默认：creative-production（业务）/ @di/npmProject（npm工程））
* 项目初始版本号(可直接回车跳过，默认：0.1.0) 
* (NPM项目选项)是否需要在发布前自动编译(默认：是，可选择否，不自动编译)
```
➜ hy-cli --create

   __   _   ___   __           ____ _     ___   __  
  / /  | | | \ \ / /          / ___| |   |_ _|  \ \ 
 / /   | |_| |\ V /   _____  | |   | |    | |    \ \
 \ \   |  _  | | |   |_____| | |___| |___ | |    / /
  \_\  |_| |_| |_|            \____|_____|___|  /_/ 
                                                    
✔ 配置信息更新成功
✔ 运行校验通过 

? 请输入项目文件夹名称 

? 请选择项目类型 
❯ 业务后台项目 
  业务前台项目 
  业务项目(前后台一体) 
  NPM项目 

请输入项目中文名称 (网易数字产业平台 / 网易数字产业平台NPM库) 

请输入项目英文名称 (creative-production / @di/npmProject) 

请输入项目初始版本号 (0.1.0) 

是否需要在发布前自动编译 (Use arrow keys)
❯ 是 
  否 
```

然后等待工程创建、npm install、lint后，看到如下信息则表示创建成功

业务项目：
```
✔ npm install...
✔ 代码格式化...
✔ 代码格式化完成
✔ 项目创建成功, 目录结构:
ℹ 
  ▸ public/
  ▾ src/
    ▸ api/                    // API
    ▸ assets/                 // 静态资源
    ▸ components/             // 组件目录
    ▸ constants/              // 常量
    ▾ entry/                  // 页面入口
      ▸ admin/                // 后台项目特有
      ▸ frontEnd/             // 前台项目特有
    ▾ layout/                 // 布局
        adminLayout.vue       // 后台项目特有
        frontEndLayout.vue    // 前台项目特有
    ▸ permissions/            // 权限相关，和现有项目一致
    ▾ router/                 // 路由
        admin.js              // 后台项目特有
        front.js              // 前台项目特有
        index.js
    ▸ setup/
    ▸ store/
    ▸ utils/
    ▾ views/
      ▸ admin/                // 后台项目页面
      ▸ common/               // 403、404
      ▸ frontEnd/             // 前台项目页面
    .browserslistrc
    .DS_Store
    .editorconfig
    .env.dev
    .env.production
    .eslintignore
    .eslintrc.js
    .gitignore
    babel.config.js
    build.sh
    package-lock.json
    package.json
    README.md
    vue.config.js

ℹ 
 使用yarn serve -- --mode dev启动本地服务
```
NPM项目：
```
✔ npm install...
✔ 代码格式化...
✔ 代码格式化完成
✔ 项目创建成功, 目录结构:
ℹ 
  ▾ src/
      ▾ core/                   // 核心功能
  .babelrc.js
  .eslintrc.js
  .gitignore
  .npmignore
  package-lock.json
  package.json
  README.md
  rollup.config.js
ℹ 
 使用 npm run dev 启动本地服务
```

完成，到项目根路径下启动本地服务！



### 初始化项目
若你已经为项目创建了git目录，则直接到git clone下来的项目目录下，执行：
```
// 选项和创建项目一致
hy-cli --init
```
 


## 联系我们
作者 | Email
--- | --- 
何文俊 | hewenjun@corp.netease.com
张乾威 ｜ zhangqianwei01@corp.netease.com

Issue反馈： [点此](https://g.hz.netease.com/commercialize/foundations/netease-hy-cli/-/issues)

## 更多
[点此](https://g.hz.netease.com/commercialize/foundations/netease-hy-cli/-/blob/master/CHANGELOG.md)查看最近更新，升级版本使用最新功能。  

# License
[MIT License(comming soon)](https://raw.githubusercontent.com/coming_soon)

