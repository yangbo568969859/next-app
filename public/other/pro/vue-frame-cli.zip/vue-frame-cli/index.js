const path = require('path');//解析需要遍历的文件夹
const rimraf = require('rimraf')
rimraf(path.join(process.cwd(), './.'), () => {})