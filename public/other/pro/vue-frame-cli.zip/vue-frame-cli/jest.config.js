const { jest } = require('./package.json')

module.exports = {
  // preset: 'ts-jest',
  coverageDirectory: 'coverage',
  testEnvironment: 'jsdom',
  reporters: ['default'],
  coverageReporters: ['html', 'lcov', 'text-summary', 'json-summary'],
  collectCoverageFrom: [
    'packages/**/*.js',
  ],
  watchPathIgnorePatterns: ['/node_modules/', '/dist/', '/.git/'],
  moduleFileExtensions: ['vue', 'js', 'json'],
  rootDir: __dirname,
  // testMatch: [
  //   '<rootDir>/tests/unit/**/*spec.[jt]s(x)?',
  // ],
  testPathIgnorePatterns: ['/node_modules/'],
  coverageThreshold: jest.coverageThreshold,
}
