const log = require('../utils/log')
const util = require('util')
const packageJSON = require('../../package.json')
const exec = util.promisify(require('child_process').exec)
const inquirer = require('inquirer')

const npmPackageName = '@di/netease-hy-cli'; 

/**
 * @description: 询问是否需要更新模版
 * @param {*} version 
 * @returns 是否更新模版
 */
const askUpdate = async (version) => {
  return await inquirer.prompt([
    {
      name: 'doUpdate',
      message:
      `最新版本: ${version}, 当前版本: ${packageJSON.version}, 是否需要更新？`,
      type: 'list',
      choices: [
        {
          name: '是',
          value: true,
        },
        {
          name: '否',
          value: false,
        },
      ],
      default: true
    }
  ])
}

/**
 * @description: 更新模版
 * @param {*} version 
 */
const updateProject = async (version) => {
  log.success(`配置信息更新成功，最新版本${version}`)
}

/**
 * @description: 比较版本号
 * @param {*} v1 最新版本
 * @param {*} v2 当前版本
 */
const compareVersion = (v1, v2) => {
  const _v1 = v1.split("."),
          _v2 = v2.split("."),
            _r = _v1[0] - _v2[0] || 0
  return _r == 0 && v1 != v2 ? compareVersion(_v1.splice(1).join("."), _v2.splice(1).join(".")) : _r
}

/**
 * @description: 模板下载
 */
const downloadConfigFromGit = async () => {
  const {err, stdout} = await exec(`npm info ${npmPackageName} version`)
  const version = stdout.trim()
  if(!err && compareVersion(version, packageJSON.version) > 0) {
    log.warn(`最新版本: ${version}, 当前版本: ${packageJSON.version}, 请及时更新！`)
    // const {doUpdate} = await askUpdate(version)
    // if(doUpdate){
    //   await updateProject(version)
    // }
  } else {
    log.success('配置信息更新成功')
  }
}

module.exports = downloadConfigFromGit