const downloadConfigFromGit = require('./download')
const projectCreater = require('./project')
const verify = require('./verify')
const showLogo = require('./utils/logo')

/**
 * @description: cli main class
 */
class Main {
  constructor(options) {
    showLogo()
    this.options = options
  }
  async run() {
    const opt = this.options

    // 更新本地配置
    await downloadConfigFromGit()

    // 运行前校验
    const pass = await verify(opt)
    if (!pass) {
      return
    }

    // 解析指令
    const key = Object.keys(opt)[0]
    switch(key) {
      case 'create':
        projectCreater(key)
        break;
      case 'init':
        projectCreater(key)
        break;
      default:
        // code block
    }
    // projectCreater
  }

  // async _verify() {
  //   const needVerify = this.needVerify(opt)
  //   if (needVerify) {
  //     // 下载配置
  //     await downloadConfigFromGit()
  //     // 验证
  //     return verify()
  //   }
  //   return true
  // }

  // _needVerify(options) {
  //   const valiActions = ['create', 'init', 'mixin', 'dev', 'local']
  //   return valiActions.includes(Object.keys(options)[0])
  // }

  // _updateTemplate(options) {
  //   const updateActions = ['create', 'init', 'mixin', 'dev', 'local']
  //   return valiActions.includes(Object.keys(options)[0])
  // }
}

module.exports = (options) => {
  return new Main(options).run()
}