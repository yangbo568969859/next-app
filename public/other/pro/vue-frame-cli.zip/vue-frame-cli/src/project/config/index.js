module.exports = {
  busBackEnd: {
    // 后台项目配置
    remove: ['src/entry/frontEnd', 'src/views/frontEnd', 'src/router/front.js', 'src/layout/frontEndLayout.vue', 'src/router/front.js'],
    template: '../template/business/.',
    runDesc: '\n\r 使用yarn serve -- --mode dev启动本地服务'
  },
  busFrontEnd: {
    // 前台项目配置
    remove: ['src/entry/admin', 'src/views/admin', 'src/router/admin.js', 'src/layout/adminLayout.vue', 'src/router/admin.js'],
    template: '../template/business/.',
    runDesc: '\n\r 使用yarn serve -- --mode dev启动本地服务'
  },
  busEnd: {
    // 前后台一体项目配置
    remove: [],
    template: '../template/business/.',
    runDesc: '\n\r 使用yarn serve -- --mode dev启动本地服务'
  },
  npm: {
    // npm 配置
    remove: [],
    template: '../template/npm/.',
    runDesc: '\n\r 使用 npm run dev 启动本地服务'
  }
}