const fs = require('fs-extra')
const path = require('path')
const util = require('util')
const ejs = require('ejs')
const rimraf = require('rimraf')
const inquirerCustom = require('./inquirer')
const ora = require('ora')
const exec = util.promisify(require('child_process').exec)

const templateConfig = require('./config')
const {iterator} = require('../utils/file')
const dirDesc = require('../template/desc')
const log = require('../utils/log')

/**
* @description: 创建业务工程
*/
class Creater {
  constructor(type, distPath) {
    this.type = type
    this.templatePath = path.join(__dirname, templateConfig[this.type].template)
    this.distPath = distPath
    this._run()
  }
  async _run () {
    // 个性化配置
    const inquirerConfig = await this._inquirerCustomConfig()
    // 获取项目参数
    this.config = this._mixinProjectConfig(inquirerConfig, templateConfig)
    // 初始化项目模板
    await this._initTemplate()
    // 创建项目文件
    await this._createProject()
    // npm install
    await this.installDep()
    // 代码格式化
    await this.lintCode()
    // 输出
    this.outputDesc()
  }

  /**
   * @description: 获取项目参数
   */  
   _mixinProjectConfig (inquirerConfig, templateConfig) {
    const config = templateConfig[this.type]
    return Object.assign({
      remove: [],
      isBusBackEnd: this.type === 'busBackEnd' || this.type === 'busEnd' ,
      isBusFrontEnd: this.type === 'busFrontEnd' || this.type === 'busEnd', 
      isNPM: this.type === 'npm',
    }, config, inquirerConfig)
  }

  /**
   * @description: 询问获取项目参数
   */  
  async _inquirerCustomConfig () {
    const inquirerConfig = inquirerCustom[this.type]
    const customConfigs = {}
    for(let i in inquirerConfig){
      const Config = await inquirerConfig[i]()
      Object.assign(customConfigs, Config)
    }
    return customConfigs
  }

  /**
   * @description: 创建工程文件
   */  
  async _createProject() {
    const files = iterator(this.distPath);
    let tpl, output
    files.forEach((p) => {
      if (/.(js|css|md|json)$/.test(p)) {
        // 需要走模板解析
        tpl = fs.readFileSync(p, 'utf8')
        try {
          output = ejs.render(tpl, this.config)
        } catch (e) {
        }
        fs.outputFileSync(p, output)
      }
    })
  }
  /**
   * @description: 初始化模板
   */  
  async _initTemplate () {
    // 复制模板
    await new Promise((resolve) => {
      fs.copy(this.templatePath, this.distPath, function (err) {
        if (err){
            log.error('log.error')
            return console.error(err)
        }
        resolve()
      });
    })
    
    // 删除无效文件
    for (const removePath of this.config.remove) {
      await rimraf(path.join(this.distPath, removePath), () => {})
    }
  }

  async installDep () {
    const spinner = ora('npm install...')
    spinner.start()
    const { err } = await exec(`cd ${this.distPath} && npm install`)
    if (err) {
      log.error('npm install失败')
      return false
    }
    spinner.succeed()
    return true
  }

  /**
   * @description: 格式化
   */
  async lintCode () {
    const spinner = ora('代码格式化...')
    spinner.start()
    const { err } = await exec(`cd ${this.distPath} && npm run lint`)
    if (err) {
      log.error('Lint fix失败')
      return false
    }
    spinner.succeed()
    log.success('代码格式化完成')
    return true
  }

  /**
   * @description: 
   */  
  outputDesc () {
    log.success('项目创建成功, 目录结构:')
    log.info(dirDesc[this.type])
    log.info(templateConfig[this.type].runDesc)
  }
}

/**
 * @description: 
 * @param {*} type: npm/busBackEnd/busFrontEnd/busEnd
 * @param {*} distPath: 输出路径
 */
module.exports = (type, distPath) => {
  return new Creater(type, distPath)
}