const fs = require('fs')
// const rimraf = require('rimraf')
// const rimraf = require('rimraf')
const path = require('path')
const inquirer = require('inquirer')
const log = require('../utils/log')

const creater = require('./creater')
/**
 * @description: 创建工程
 */
class Creater {
  constructor(action) {
    this.action = action
    this._run()
  }
  async _run () {
    // 先创建项目文件夹
    const projectPath = this.action === 'create' ? await this._createFolden() : process.cwd()
    // 项目名称
    const projectType = await this._initProject()
    // 初始化项目
    creater(projectType, projectPath)
  }

  /**
   * @description: 创建工程文件夹
   * @return String: distPath
   */  
  async _createFolden() {
    const { foldName } = await inquirer.prompt([
      {
        name: 'foldName',
        message:
          '请输入项目文件夹名称',
        type: 'input',
      }
    ])
    if (!/^[a-zA-Z\-]{4,35}$/.test(foldName)) {
      log.error('名称由4-35位的字母、 \'-\'组成')
      return await this._createFolden()
    }

    const projectPath = path.join(process.cwd(),foldName)
    if (fs.existsSync(projectPath)) {
      log.error('目录已存在')
      return await this._createFolden()
    }
    const distPath = path.join(process.cwd(), foldName)
    fs.mkdirSync(distPath)
    return distPath
  }

  /**
   * @description: 初始化工程
   */  
  async _initProject() {
    const { projectType } = await inquirer.prompt([
      {
        name: 'projectType',
        message:
          '请选择项目类型',
        type: 'list',
        choices: [
          {
            name: '业务后台项目',
            value: 'busBackEnd',
          },
          {
            name: '业务前台项目',
            value: 'busFrontEnd',
          },
          {
            name: '业务项目(前后台一体)',
            value: 'busEnd',
          },
          {
            name: 'NPM项目',
            value: 'npm',
          }
        ],
        default: 'busBackEnd'
      }
    ])
    return projectType
  }
}

module.exports = (action) => {
  return new Creater(action)
}