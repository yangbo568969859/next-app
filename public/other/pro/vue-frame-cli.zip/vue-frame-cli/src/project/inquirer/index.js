const inquirer = require('inquirer')

const getZhName = async () => {
  return await inquirer.prompt([
    {
      name: 'zhName',
      message:
        '请输入项目中文名称',
      type: 'input',
      default: '网易数字产业平台'
    }
  ])
}

const getNpmZhName = async () => {
  return await inquirer.prompt([
    {
      name: 'zhName',
      message:
        '请输入项目中文名称',
      type: 'input',
      default: '网易数字产业平台NPM库'
    }
  ])
}

const getNpmEnName = async () => {
  return await inquirer.prompt([
    {
      name: 'enName',
      message:
        '请输入项目英文名称',
      type: 'input',
      default: '@di/npmProject'
    }
  ])
}

const getEnName = async () => {
  return await inquirer.prompt([
    {
      name: 'enName',
      message:
        '请输入项目英文名称',
      type: 'input',
      default: 'creative-production'
    }
  ])
}

const getVersion = async () => {
  return await inquirer.prompt([
    {
      name: 'version',
      message:
        '请输入项目初始版本号',
      type: 'input',
      default: '0.1.0'
    }
  ])
}

const getCompileChoice = async () => {
  return await inquirer.prompt([
    {
      name: 'needCompile',
      message:
        '是否需要编译',
      type: 'list',
      choices: [
        {
          name: '是',
          value: true,
        },
        {
          name: '否',
          value: false,
        },
      ],
      default: true
    }
  ])
}

module.exports = {
  busBackEnd: [getZhName, getEnName, getVersion],
  busFrontEnd: [getZhName, getEnName, getVersion],
  busEnd: [getZhName, getEnName, getVersion],
  npm: [getNpmZhName, getNpmEnName, getVersion, getCompileChoice]
}