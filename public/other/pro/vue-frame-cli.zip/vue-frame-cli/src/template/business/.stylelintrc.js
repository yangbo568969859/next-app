module.exports = {
  "extends": "stylelint-config-standard",
  "rules": {
    "unit-no-unknown": [
      true,
      { ignoreUnits: ["x"] }
    ]
  }
}
