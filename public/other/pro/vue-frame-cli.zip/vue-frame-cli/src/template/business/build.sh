# 推荐使用淘宝源
echo "npm config set registry https://registry.npm.taobao.org"
npm config set registry https://registry.npm.taobao.org

# 配置公司私有npm仓库
echo "npm config set @di:registry http://rnpm.hz.netease.com"
npm config set @di:registry http://rnpm.hz.netease.com

echo "npm install"
npm install

if [ -n "$1" ];then
  echo "npm run build -- --mode $1"
  npm run build -- --mode $1
else
  echo "npm run build"
  npm run build
fi
