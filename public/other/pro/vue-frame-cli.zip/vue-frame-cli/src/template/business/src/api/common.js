import request from '@/utils/request'
import APIS from '@/permissions/index'
import { getCheckList } from '@/permissions/util'

export function checkPermissions () {
  return request({
    ...APIS['@common/CHECK_PERMISSIONS'],
    data: getCheckList()
  })
}

export function getUserInfo () {
  return request(APIS['@common/GET_USER_INFO'])
}

export function logout () {
  return request(APIS['@common/LOGOUT'])
}
