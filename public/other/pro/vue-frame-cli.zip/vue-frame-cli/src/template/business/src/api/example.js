import request from '@/utils/request'
import APIS from '@/permissions/index'

export function getSiteList (params) {
  return request({
    ...APIS['@example/GET_EXAMPLE_LIST'],
    params
  })
}
