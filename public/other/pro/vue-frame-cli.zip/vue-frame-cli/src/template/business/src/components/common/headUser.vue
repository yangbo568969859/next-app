<template>
  <a-dropdown
    v-model="visible"
    placement="bottomRight"
  >
    <div class="m-user-info">
      <img class="avatar" :src="userInfo.imageUrl" alt="">
    </div>
    <a-menu slot="overlay" class="m-user-menu">
      <a-menu-item class="no-transition">
        <div class="m-user-detail">
          <img
            :src="userInfo.imageUrl"
            class="avatar"
          >
          <div class="m-user-flex">
            <span class="u-user">
              <span class="u-user-name">{{ userInfo.name || '' }}</span>
            </span>
            <span class="u-user-info">{{ userInfo.organizationName }}</span>
          </div>
        </div>
      </a-menu-item>
      <a-menu-item
        v-for="(operate, index) in operateList"
        :key="index"
        class="m-user-list"
        @click="emitEvent(operate)"
      >
        <a-badge v-if="operate.num" count="5">
          <span class="title">{{ operate.title }}</span>
        </a-badge>
        <span v-else class="title">{{ operate.title }}</span>
      </a-menu-item>
    </a-menu>
  </a-dropdown>
</template>

<script>
export default {
  props: {
    userInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
    operateList: {
      type: Array,
      default: () => [
        // {
        //   title: '消息',
        //   action: 'message',
        //   num: 10
        // },
        {
          title: '退出登录',
          action: 'logout'
        }
      ]
    }
  },
  data () {
    return {
      visible: false
    }
  },
  methods: {
    emitEvent (operate) {
      this.visible = false
      this.$emit(operate.action)
    }
  }
}
</script>

<style lang="less">
.m-user {
  &-info {
    height: 100%;
    display: flex;
    align-items: center;
    cursor: pointer;

    .name {
      margin-right: 13px;
      background: #526390;
      border-radius: 4px;
      padding: 2px 6px;
      font-size: 12px;
      color: #c3d6fd;
      line-height: 18px;
    }

    .avatar {
      width: 28px;
      height: 28px;
      object-fit: contain;
      border-radius: 28px;
    }

    .icon {
      width: 0;
      height: 0;
      margin-left: 8px;
      display: inline-block;
      border-left: 4px solid transparent;
      border-right: 4px solid transparent;
      border-top: 6px solid rgba(255, 255, 255, 0.56);
    }
  }

  &-detail {
    display: flex;
    padding-right: 4px;
    flex-wrap: wrap;

    .avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 15px;
    }
  }

  &-list {
    padding: 5px 24px !important;
    line-height: 30px !important;

    .title {
      padding-right: 10px;
    }
  }

  &-menu {
    box-shadow: 0 10px 80px 10px rgba(1, 3, 10, 10%) !important;
    border-radius: 8px;
    padding: 14px 0 12px !important;
    min-width: 230px;
  }

  &-flex {
    display: flex;
    justify-content: center;
    flex-direction: column;
    cursor: text;
  }
}

.u-user {
  margin-bottom: 8px;
  line-height: 22px;
  font-size: 12px;
  color: '#102048';

  &-info {
    line-height: 17px;
    font-size: 12px;
  }

  &-name {
    font-size: 16px;
    color: #102048;
    font-weight: 600;
  }
}

.no-transition {
  cursor: default;
  margin: 0 24px 8px !important;
  border-bottom: 1px solid #e7e7e9;
  padding: 0 !important;
  padding-bottom: 12px !important;

  &:hover {
    background: #fff !important;
  }
}
</style>
