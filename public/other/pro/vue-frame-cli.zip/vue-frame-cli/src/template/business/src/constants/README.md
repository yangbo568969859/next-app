## 常量
```javascript
export const EXAMPLE = []
```