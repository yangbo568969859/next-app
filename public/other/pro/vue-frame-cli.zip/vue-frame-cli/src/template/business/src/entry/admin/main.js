import Vue from 'vue'
import VueRouter from 'vue-router'
import { Modal, message } from 'ant-design-vue'
import App from './App.vue'
import router from '@/router/admin'
import store from '@/store'
import { hasPermissions } from '@/permissions/util'

// 注册ant-design-vue组件
import '@/setup/ant-design-vue/index'

import '@/assets/less/global.less'

Vue.use(Modal)
Vue.prototype.$confirm = Modal.confirm

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push (location) {
  return originalPush.call(this, location).catch(err => err)
}

router.beforeEach((to, from, next) => {
  if (!/^\/admin\//.test(to.path) || /\/403|404/.test(to.path)) {
    return next()
  }
  if (Object.keys(store.state.apis).length === 0) {
    store.dispatch('updateApis').then(() => {
      check(to, next)
    })
  } else {
    check(to, next)
  }

  window.scrollTo(0, 0)
})

function check (to, next) {
  if (hasPermissions(store.state.apis, to.meta.apis, to.meta.someApis)) {
    if (to.path === '/') {
      const routers = router.options.routes
      const apis = store.state.apis
      for (const route in routers) {
        for (const item in apis) {
          if (routers[route].path === '/403') {
            next({ path: '/403', replace: true, query: { noGoBack: true } })
            return
          }
          if (routers[route].meta && apis[item]) {
            if ((routers[route].meta.apis && routers[route].meta.apis.includes(item)) ||
              (routers[route].meta.someApis && routers[route].meta.someApis.includes(item))
            ) {
              next(routers[route].path)
              return
            }
          }
        }
      }
    }
    next()
  } else {
    next({ path: '403', replace: true, query: { noGoBack: true } })
  }
}

// 事件总线
Vue.prototype.eventBus = new Vue()
// 全局警告提示
Vue.prototype.$message = message

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
