import Vue from 'vue'
import { Modal, message } from 'ant-design-vue'
import App from './App.vue'
import router from '@/router/front'
import store from '@/store'

// 注册ant-design-vue组件
import '@/setup/ant-design-vue/index'

import '@/assets/less/global.less'

Vue.config.productionTip = false
Vue.use(Modal)
Vue.prototype.$confirm = Modal.confirm

// 事件总线
Vue.prototype.eventBus = new Vue()
// 全局警告提示
Vue.prototype.$message = message

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
