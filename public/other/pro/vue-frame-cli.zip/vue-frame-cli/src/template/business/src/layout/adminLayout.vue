<template>
  <a-layout class="back-layout">
    <a-layout-header class="back-header">
      <div>
        <div class="m-site-name">
          <div class="m-site-icon">
            <a-icon
              class="trigger"
              :type="collapsed ? 'menu-unfold' : 'menu-fold'"
              @click="() => (collapsed = !collapsed)"
            />
          </div>
          <span class="line" />
          <div class="logo z-ellipsis">
            <!-- <svg class="local-icon" aria-hidden="true">
              <use xlink:href="#iconyiqianmian-bai"></use>
            </svg> -->
          </div>
        </div>
      </div>
      <div class="head-opts">
        <head-user
          :user-info="userInfo"
          @logout="logout"
        />
      </div>
    </a-layout-header>
    <a-layout>
      <a-layout-sider
        v-model="collapsed"
        theme="light"
        :trigger="null"
        collapsible
        :collapsed-width="60"
      >
        <a-menu
          mode="inline"
          :selected-keys="selectedKeys"
          :default-open-keys="openKeys"
          @click="onMenuClick"
        >
          <template v-for="item in menus">
            <template v-if="item.hasPermissions">
              <a-menu-item v-if="!item.children" :key="item.key">
                <a-icon v-if="item.icon" :type="item.icon" />
                <span>{{ item.title }}</span>
              </a-menu-item>
              <sub-menu v-else :key="item.key" :menu-info="item" />
            </template>
          </template>
        </a-menu>
      </a-layout-sider>
      <a-layout>
        <a-layout-content class="back-layout-content">
          <router-view />
        </a-layout-content>
        <a-layout-footer :style="{ textAlign: 'center', padding: '16px 0'}">
          copyright ©{{ moment(new Date()).format('YYYY') }} 网易出品
        </a-layout-footer>
      </a-layout>
    </a-layout>
  </a-layout>
</template>

<script>
import moment from 'moment'
import { Menu } from 'ant-design-vue'
import HeadUser from '@/components/common/headUser'
import { hasPermissions } from '@/permissions/util'
const SubMenu = {
  template: `
    <a-sub-menu :key="menuInfo.key" v-bind="$props" v-on="$listeners">
      <span slot="title">
        <a-icon v-if="menuInfo.icon" :type="menuInfo.icon" /><span>{{ menuInfo.title }}</span>
      </span>
      <template v-for="item in menuInfo.children">
        <template v-if="item.hasPermissions">
          <a-menu-item v-if="!item.children" :key="item.key">
            <span>{{ item.title }}</span>
          </a-menu-item>
          <sub-menu v-else :key="item.key" :menu-info="item" />
        </template>
      </template>
    </a-sub-menu>
  `,
  name: 'SubMenu',
  isSubMenu: true,
  props: {
    ...Menu.SubMenu.props,
    menuInfo: {
      type: Object,
      default: () => ({})
    }
  }
}

export default {
  components: {
    HeadUser,
    SubMenu
  },
  data () {
    return {
      collapsed: false,
      openKeys: [],
      selectedKeys: [],
      unreadTotal: 0
    }
  },
  computed: {
    apis () {
      return this.$store.state.apis
    },
    userInfo () {
      return this.$store.state.userInfo
    },
    menus () {
      this.menuConfig.forEach(menu => {
        menu.hasPermissions = hasPermissions(this.apis, menu.apis, menu.someApis)
        if (menu.children) {
          menu.children.forEach(item => {
            item.hasPermissions = hasPermissions(this.apis, item.apis, item.someApis)
          })
        }
      })
      return this.menuConfig
    },
    breadcrumb () {
      return this.$store.state.breadcrumb
    },
    menuConfig () {
      return [
        {
          icon: 'user',
          key: '/admin/demo1',
          title: '测试页面1',
          // someApis: ['@common/LOGOUT']
          apis: ['@common/LOGOUT']
        },
        {
          icon: 'user',
          key: '/admin/demo2',
          title: '测试页面2',
          apis: ['@common/LOGOUT']
        },
        {
          // 无权限 403
          icon: 'user',
          key: '/admin/demo3',
          title: '测试页面3(403)'
        },
        {
          // 空页面 跳404
          icon: 'user',
          key: '/admin/demo4',
          title: '测试页面4(404)'
        }
      ]
    }
  },
  watch: {
    $route (to) {
      this.updateMenu(to.path)
    }
  },
  beforeCreate () {
    // 路由拦截处已调用
    this.$store.dispatch('getUserInfo')
  },
  created () {
    this.updateMenu(this.$route.path)
  },
  methods: {
    moment,
    beforeunload (event) {
      if (this.$store.state.isUploading) {
        const confirmationMessage = '刷新页面会导致文件上传终止，是否还要刷新?'
        const e = event || window.event
        e.returnValue = confirmationMessage
        return confirmationMessage
      }
    },
    onMenuClick ({ key }) {
      if (this.$route.path !== key) {
        this.$router.push(key)
      }
    },
    updateMenu (path) {
      const config = this.menuConfig

      // 遍历菜单配置项
      const travel = (list = [], path) => {
        if (!list.length) {
          return []
        }

        let openKeys = []
        let selectedKey = ''

        for (let i = 0; i < list.length; i++) {
          const { key, children } = list[i]
          const isSubMenu = children && children.length

          if (isSubMenu) {
            const [o, s] = travel(children, path)
            if (s) {
              openKeys = [key].concat(o)
              selectedKey = s
              break
            }
          } else if ((key === path) || (path.indexOf(key) === 0)) {
            // 当路由完全匹配 or 匹配上前缀即认为当前页面在该菜单项下
            selectedKey = key
            break
          }
        }

        this.$store.commit('updateBreadcrumb')

        return [openKeys, selectedKey]
      }

      const [openKeys = [], selectedKey] = travel(config, path)

      this.selectedKeys = selectedKey ? [selectedKey] : []
      this.openKeys = Array.from(new Set([].concat(this.openKeys, openKeys)))
    },
    logout () {
      this.$store.dispatch('logout')
    },
    updateSiteId (siteId = '') {
      this.$store.commit('updateSiteId', siteId)
    },
    switchAccess () {
      const url = `${this.$store.state.domainData.manageDomain}/rights/setted`
      window.open(url)
    }
  }
}
</script>

<style lang="less">
@import '@/assets/less/back-layout.less';

.back-layout {
  &-content {
    min-height: calc(100vh - 105px) !important;
  }
}
</style>
<style lang="less">
.m-site-name {
  display: flex;
}

.site-name {
  color: #fff;
  margin-left: 20px;
}

.m-site-icon {
  width: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.ant-layout {
  min-height: 100%;
  background: #f0f2f5;

  .g-header.u-header {
    padding: 0 45px 0 0;
    box-shadow: 0 2px 14px 0 rgba(0, 0, 0, 0.05);
  }

  .ant-menu-inline-collapsed {
    width: 60px;
  }

  .trigger {
    font-size: 18px;
    line-height: 52px;
    cursor: pointer;
    transition: color 0.3s;
    vertical-align: middle;
    display: inline-block;
    color: #fff;
  }

  .back-header {
    background: #2d3b5f;
    padding: 0;
    z-index: 1;
    display: flex;
    justify-content: space-between;
    padding-right: 40px;
    box-shadow: 0 2px 14px rgba(0, 0, 0, 0.05);
  }

  .ant-layout-sider {
    background: #fff;
  }

  .ant-layout-header {
    height: 52px;
    line-height: 52px;
  }

  .line {
    width: 1px;
    height: 52px;
    background: #fff;
    opacity: 0.2;
    position: absolute;
    top: 0;
    left: 59px;
  }

  .logo {
    height: 32px;
    // background: rgba(255, 255, 255, 0.2);
    color: #fff;
    line-height: 32px;
    margin: 10px 16px;
    display: inline-block;

    .local-icon {
      font-size: 32px;
      width: 4em;

      &.z-small {
        width: 1em;
        margin-left: 0.2em;
      }
    }
  }

  .ant-menu {
    user-select: none;
  }

  .ant-layout-footer {
    background-color: transparent;
    color: rgba(16, 32, 72, 0.25);
  }
}

.head-opts {
  display: flex;
  align-items: center;
}

.m-message {
  margin-right: 20px;
  vertical-align: middle;

  a {
    margin-right: 5px;
  }

  .u-bell {
    font-size: 17px;
    color: #333;

    &:hover {
      color: #40a9ff;
    }

    &:active {
      color: #096dd9;
    }
  }
}

.ant-menu-inline-collapsed >.ant-menu-item,
.ant-menu-inline-collapsed >.ant-menu-item-group >.ant-menu-item-group-list >.ant-menu-item,
.ant-menu-inline-collapsed >.ant-menu-item-group >.ant-menu-item-group-list >.ant-menu-submenu >.ant-menu-submenu-title,
.ant-menu-inline-collapsed >.ant-menu-submenu >.ant-menu-submenu-title {
  padding: 0 22px !important;
}
</style>
