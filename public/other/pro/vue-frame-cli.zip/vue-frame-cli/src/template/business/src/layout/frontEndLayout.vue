<template>
  <div class="front-layout">
    <header class="navbar">
      <div class="navbar-left">
        <div class="logo" @click="refreshPage">
          <img
            :src="logo"
            alt=""
          >
        </div>
        <div class="menu">
          <div
            v-for="(menu, index) in menuList"
            :key="index"
            :class="['menu-item', selectMenu === menu.pathName ? 'active' : '']"
            @click="goPage(menu)"
          >
            {{ menu.title }}
          </div>
        </div>
      </div>
      <div class="navbar-right">
        <head-user
          :user-info="userInfo"
          :operate-list="operateList"
          @action="actionHandle"
        />
      </div>
    </header>
    <div class="front-layout-content">
      <router-view />
    </div>
  </div>
</template>

<script>
import logo from '../assets/image/logo.png'
import HeadUser from '@/components/common/headUser'
const operateList = [
  {
    title: '退出登录',
    action: 'logout'
  }
]
const menuList = [
  {
    pathName: 'demo1',
    path: '',
    title: 'Demo1'
  },
  {
    pathName: 'demo2',
    path: '',
    title: 'Demo2'
  }
]
export default {
  components: {
    HeadUser
  },
  data () {
    return {
      operateList,
      menuList,
      selectMenu: menuList[0].pathName,
      logo
    }
  },
  computed: {
    userInfo () {
      return this.$store.state.userInfo
    }
  },
  watch: {
    $route: {
      handler: function (val) {
        this.selectMenu = val.name
      }
    }
  },
  beforeCreate () {
    // 路由拦截处已调用
    this.$store.dispatch('getUserInfo')
  },
  created () {
    this.getSelectMenu()
  },
  methods: {
    getSelectMenu () {
      this.selectMenu = this.$route.name
    },
    goPage (menu) {
      this.$router.push({
        name: menu.pathName
      })
    },
    actionHandle (type) {
      switch (type) {
        case 'logout':
          this.logout()
          break
        default:
          break
      }
    },
    logout () {
      this.$store.dispatch('logout')
    },
    refreshPage () {
      location.href = '/'
    }
  }
}
</script>

<style lang="less">
@import '@/assets/less/front-layout.less';
@header-height: 58px;

.front-layout {
  .navbar {
    padding: 0 48px 0 30px;
    margin-bottom: 0;
    min-height: @header-height;
    border: 0;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    border-radius: 0;
    display: flex;
    justify-content: space-between;
    box-shadow: 0 2px 14px rgba(0, 0, 0, 0.05);
    z-index: 100;
    background: #fff;

    &-left {
      display: flex;

      .logo {
        width: 140px;
        margin-right: 20px;
        display: flex;
        align-items: center;
        justify-content: center;

        img {
          width: 100px;
          height: 50px;
          cursor: pointer;
        }
      }

      .menu {
        display: flex;
      }

      .menu-item {
        line-height: @header-height;
        margin-right: 20px;
        cursor: pointer;
        transition: all 0.25s ease;

        &.active {
          color: #3360ff;
        }

        &:hover {
          color: #3360ff;
        }
      }
    }
  }

  &-content {
    padding-top: @header-height;
  }
}
</style>
