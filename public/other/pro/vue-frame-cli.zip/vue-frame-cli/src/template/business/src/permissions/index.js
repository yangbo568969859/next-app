import { getApis } from './util'

export default getApis()
