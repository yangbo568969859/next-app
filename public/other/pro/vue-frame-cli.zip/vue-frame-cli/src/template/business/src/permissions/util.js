const configJson = require.context('./config', true, /\.json$/)
const apis = {}
configJson.keys().forEach(key => {
  apis[key.replace(/^\.\/([A-Za-z0-9_-]+)\.json$/, ($1, $2) => $2)] = configJson(key)
})

/**
 * 获取 指定/全部 模块列表
 * @param {Array} keys 模块名称列表
 */
export function getApis (keys) {
  let temp = {}
  const res = {}
  if (keys) {
    keys.forEach(key => {
      if (apis[key]) {
        temp[key] = { ...apis[key] }
      }
    })
  } else {
    temp = { ...apis }
  }

  Object.keys(temp).forEach(key => {
    const moduleApis = temp[key]
    Object.keys(moduleApis).forEach(lessKey => {
      const moduleApi = moduleApis[lessKey]
      res[`@${key}/${lessKey}`] = moduleApi
    })
  })
  return res
}

/**
 * 获取 指定/全部 权限模块请求列表
 * @param {Array} keys 模块名称列表
 */
export function getCheckList (keys) {
  const api = getApis(keys)
  const res = {}

  Object.keys(api).forEach(key => {
    if (api[key] && api[key].resource) {
      res[key] = api[key].resource
    }
  })
  return res
}

/**
 * 校验数据
 * @param {Object} allApis 所有接口权限
 * @param {Array} needApis 全部必须的接口列表
 * @param {Array} someApis 只要有一个满足即可
 */
export function hasPermissions (allApis, needApis = [], someApis = []) {
  let has = true

  needApis.every(key => {
    if (!allApis[key]) {
      has = false
      return false
    }
    return true
  })

  if (has && someApis.length > 1) {
    has = false

    someApis.some(key => {
      if (allApis[key]) {
        has = true
        return true
      }
      return false
    })
  }

  return has
}
