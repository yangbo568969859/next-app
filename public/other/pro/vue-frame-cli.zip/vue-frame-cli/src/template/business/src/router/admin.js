import AdminLayout from '@/layout/adminLayout'
import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [{
  path: '/admin',
  component: AdminLayout,
  children: [
    {
      path: '/',
      redirect: '/admin/demo1'
    },
    {
      path: 'demo1',
      name: 'demo1',
      component: () => import(/* webpackChunkName: "about" */ '@/views/admin/demo1/index.vue'),
      meta: {
        someApis: ['@common/LOGOUT']
      }
    },
    {
      path: 'demo2',
      name: 'demo2',
      component: () => import(/* webpackChunkName: "about" */ '@/views/admin/demo2/index.vue'),
      meta: {
        // someApis: ['@common/LOGOUT'],
        apis: ['@common/LOGOUT']
      }
    },
    {
      path: 'demo3',
      name: 'demo3',
      component: () => import(/* webpackChunkName: "about" */ '@/views/admin/demo2/index.vue'),
      meta: {
        // 测试，无权限访问
        // someApis: ['@common/LOGOUT'],
        apis: ['@common/LOGOUT2']
      }
    },
    {
      path: '403',
      name: '403',
      component: () => import(/* webpackChunkName: "about" */ '@/views/common/403/index.vue')
    },
    {
      path: '404',
      name: '404',
      component: () => import(/* webpackChunkName: "about" */ '@/views/common/404/index.vue')
    }, {
      path: '*', // 此处需特别注意至于最底部
      redirect: '404'
    }
  ]
}]

const router = new VueRouter({
  mode: 'history',
  base: '/',
  routes
})

export default router
