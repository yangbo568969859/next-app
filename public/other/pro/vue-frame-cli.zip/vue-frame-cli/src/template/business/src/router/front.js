import Vue from 'vue'
import VueRouter from 'vue-router'
import FrontEndLayout from '@/layout/frontEndLayout'

Vue.use(VueRouter)

const routes = [{
  path: '/',
  component: FrontEndLayout,
  children: [
    {
      path: '/',
      redirect: '/demo1'
    },
    {
      path: '/demo1',
      name: 'demo1',
      component: () => import(/* webpackChunkName: "about" */ '@/views/frontEnd/demo1/index.vue'),
      meta: {
        someApis: ['@site/GET_SITE_LIST', '@site/GET_TEMPLATE_LIST']
      }
    },
    {
      path: '/demo2',
      name: 'demo2',
      component: () => import(/* webpackChunkName: "about" */ '@/views/frontEnd/demo2/index.vue'),
      meta: {
        someApis: ['@site/GET_SITE_LIST', '@site/GET_TEMPLATE_LIST']
      }
    }
  ]
}]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
