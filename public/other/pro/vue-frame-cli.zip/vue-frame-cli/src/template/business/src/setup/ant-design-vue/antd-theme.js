const modifyVars = {
  'primary-color': '#3360FF',
  'heading-color': '#26385b',
  'text-color': '#102048',
  'outline-width': '1px',
  'font-family': '-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,PingFang SC,Noto Sans,Noto Sans CJK SC,Microsoft YaHei,sans-serif'
}

module.exports = modifyVars
