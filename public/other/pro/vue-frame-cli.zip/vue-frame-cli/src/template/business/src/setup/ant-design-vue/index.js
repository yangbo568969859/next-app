import Vue from 'vue'
import {
  Layout,
  Menu,
  Icon,
  Button,
  Dropdown,
  Tabs,
  Card,
  Breadcrumb,
  Form,
  Upload,
  Input,
  Row,
  Col,
  Table,
  Divider,
  Switch,
  DatePicker,
  Modal,
  Radio,
  Avatar,
  Empty,
  Tag,
  Spin,
  message,
  ConfigProvider,
  Checkbox,
  Badge,
  Select,
  Popover,
  Pagination,
  Cascader,
  InputNumber,
  TreeSelect,
  Steps,
  Tooltip,
  List
} from 'ant-design-vue'

Vue.component(Layout.name, Layout)
Vue.component(Layout.Sider.name, Layout.Sider)
Vue.component(Layout.Header.name, Layout.Header)
Vue.component(Layout.Footer.name, Layout.Footer)
Vue.component(Layout.Content.name, Layout.Content)
Vue.component(Menu.name, Menu)
Vue.component(Menu.SubMenu.name, Menu.SubMenu)
Vue.component(Menu.Item.name, Menu.Item)
Vue.component(Icon.name, Icon)
Vue.component(Button.name, Button)
Vue.component(Dropdown.name, Dropdown)
Vue.component(Tabs.name, Tabs)
Vue.component(Tabs.TabPane.name, Tabs.TabPane)
Vue.component(Card.name, Card)
Vue.component(Card.Meta.name, Card.Meta)
Vue.component(Breadcrumb.name, Breadcrumb)
Vue.component(Breadcrumb.Item.name, Breadcrumb.Item)
Vue.component(Form.name, Form)
Vue.component(Form.Item.name, Form.Item)
Vue.component(Upload.name, Upload)
Vue.component(Upload.Dragger.name, Upload.Dragger)
Vue.component(Input.name, Input)
Vue.component(Row.name, Row)
Vue.component(Col.name, Col)
Vue.component(Table.name, Table)
Vue.component(Divider.name, Divider)
Vue.component(Input.TextArea.name, Input.TextArea)
Vue.component(Input.Search.name, Input.Search)
Vue.component(Radio.name, Radio)
Vue.component(Radio.Group.name, Radio.Group)
Vue.component(Switch.name, Switch)
Vue.component(DatePicker.name, DatePicker)
Vue.component(DatePicker.RangePicker.name, DatePicker.RangePicker)
Vue.component(Avatar.name, Avatar)
Vue.component(Empty.name, Empty)
Vue.component(Tag.name, Tag)
Vue.component(Spin.name, Spin)
Vue.component(ConfigProvider.name, ConfigProvider)
Vue.component(Checkbox.name, Checkbox)
Vue.component(Checkbox.Group.name, Checkbox.Group)
Vue.component(Badge.name, Badge)
Vue.component(Popover.name, Popover)
Vue.component(Pagination.name, Pagination)
Vue.component(Cascader.name, Cascader)
Vue.component(InputNumber.name, InputNumber)
Vue.component(TreeSelect.name, TreeSelect)
Vue.component(Tooltip.name, Tooltip)

// Vue.component(Modal.name, Modal)
Vue.use(Modal) // 不这样写会报错
Vue.use(Select) // 不这样写会报错
Vue.use(Steps) // 不这样写会报错
Vue.use(List)

Vue.prototype.$message = message
Vue.prototype.$confirm = Modal.confirm
