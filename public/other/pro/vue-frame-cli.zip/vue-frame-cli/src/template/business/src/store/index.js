import Vue from 'vue'
import Vuex from 'vuex'
import { checkPermissions, getUserInfo, logout } from '@/api/common'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    apis: {},
    userInfo: {}
  },
  mutations: {
    updateUserInfo (state, userInfo) {
      state.userInfo = userInfo
    },
    updateApis (state, apis) {
      state.apis = { ...state.apis, ...apis }
    }
  },
  actions: {
    updateApis (context) {
      return checkPermissions().then(res => {
        const accessApi = res.accessApi

        context.commit('updateApis', accessApi)
      })
    },
    getUserInfo (context) {
      getUserInfo().then(res => {
        context.commit('updateUserInfo', res)
      })
    },
    logout (context) {
      logout().then(res => {
        context.commit('updateUserInfo', {})
        location.href = `${process.env.VUE_APP_PASSPORT_URL}/login?referrer=${encodeURIComponent(location.origin)}`
      })
    }
  },
  modules: {
  }
})
