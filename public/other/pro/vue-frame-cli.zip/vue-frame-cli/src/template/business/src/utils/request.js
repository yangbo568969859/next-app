import axios from 'axios'
import Qs from 'qs'
import { message } from 'ant-design-vue'
// 创建axios实例
const service = axios.create({
  baseURL: '/api',
  withCredentials: true,
  paramsSerializer: params => Qs.stringify(params, { arrayFormat: 'comma' }),
  headers: {
    'Content-Type': 'application/json', // application/x-www-form-urlencoded;charset=utf-8;
    'Access-Control-Allow-Origin': '*'
  },
  timeout: 15000 // 请求超时时间
})

service.interceptors.request.use(config => {
  const params = config.data ? config.data : {}
  if (params) {
    const _params = {}
    for (const [key, value] of Object.entries(params)) {
      const _url = config.url
      config.url = config.url.replace(new RegExp('\\{' + key + '\\}', 'g'), value)
      if (_url === config.url) {
        _params[key] = value
      }
    }
    config.data = _params
  }
  return config
})
service.interceptors.response.use(
  response => {
    const res = response.data
    if (res.code === 200) {
      return res.data || res.result
    } else if (res.code === 403) {
      // 未授权页面跳转
      window.location.href = '#'
    } else {
      message.error(res.message || '服务器异常')
      return Promise.reject(res.message)
    }
  },
  error => {
    if (error.response.status === 401) {
      location.href = `${process.env.VUE_APP_PASSPORT_URL}/login?referrer=${encodeURIComponent(location.href)}`
    } else {
      message.error(error.response.data.message || '服务器异常')
    }
    return Promise.reject(error)
  }
)
export default service
