<template>
  <div class="s-center">
    <img
      src="@/assets/image/403.png"
      alt=""
    >
    <div style="margin-left: 121px;">
      <!-- <div class="s-pone">
        403
      </div> -->
      <div class="s-ptwo">
        <!-- 你没有管理权限，请向申请开通。 -->
        无权访问，请联系管理员
      </div>
      <a-button
        type="primary"
        @click="gotoindex"
      >
        返回首页
      </a-button>
    </div>
  </div>
</template>

<script>
import { Button } from 'ant-design-vue'

export default {
  components: {
    [Button.name]: Button
  },
  created () {
  },
  mounted () {
  },
  // computed: {
  //   userInfo () {
  //     // 开发者酌情考虑使用
  //     return this.$store.state.userInfo
  //   }
  // },
  methods: {
    gotoindex () {
      // TODO 自行填写首页
      // location.href = process.env.VUE_APP_PORTAL_URL
    }
  }
}
</script>
<style scoped lang="less">
.s-center {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  .s-pone {
    font-size: 73px;
    font-weight: bold;
    // margin-bottom: 24px;
  }

  .s-ptwo {
    color: #8a8b8d;
    // font-family: PingFang SC;
    font-weight: regular;
    font-size: 20px;
    line-height: 28px;
    margin-bottom: 16px;
  }
}

</style>
