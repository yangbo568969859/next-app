<template>
  <div class="s-center">
    <img
      src="@/assets/image/404.png"
      alt=""
    >
    <div style="margin-left: 121px;">
      <div class="s-pone">
        404
      </div>
      <div class="s-ptwo">
        抱歉，你访问的页面不存在
      </div>
      <a-button
        type="primary"
        @click="gotoindex"
      >
        返回首页
      </a-button>
    </div>
  </div>
</template>

<script>
import { Button } from 'ant-design-vue'

export default {
  components: {
    [Button.name]: Button
  },
  data () {
    return {
    }
  },
  computed: {

  },
  created () {

  },
  mounted () {

  },
  methods: {
    gotoindex () {
      // TODO 自行填写首页
      // this.$router.push('/')
    }
  }
}
</script>
<style scoped lang="less">
.s-center {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  .s-pone {
    font-size: 73px;
    font-weight: bold;
    // margin-bottom: 24px;
  }

  .s-ptwo {
    color: #8a8b8d;
    // font-family: PingFang SC;
    font-weight: regular;
    font-size: 20px;
    line-height: 28px;
    margin-bottom: 16px;
  }
}

</style>
