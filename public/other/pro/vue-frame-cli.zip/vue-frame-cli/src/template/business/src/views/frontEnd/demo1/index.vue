<template>
  <div class="m-rights">
    frontEnd demo1
  </div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style lang="less" scoped>
</style>
