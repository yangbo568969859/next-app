const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
const CompressionPlugin = require('compression-webpack-plugin')
const webpack = require('webpack')
const path = require('path')
const modifyVars = require('./src/setup/ant-design-vue/antd-theme.js')

module.exports = {
  pages: {
    <% if (isBusFrontEnd) { %>
    home: {
      entry: 'src/entry/frontEnd/main.js',
      template: 'public/index.html',
      filename: 'index.html',
      title: '<%= zhName %>'
    },
    <% } %>
    <% if (isBusBackEnd) { %>
    admin: {
      entry: 'src/entry/admin/main.js',
      template: 'public/index.html',
      filename: 'admin.html',
      title: '<%= zhName %>-管理'
    }
    <% } %>
  },
  lintOnSave: false,
  devServer: {
    port: 8080,
    host: 'test.163yun.com', // 本地开发域名
    disableHostCheck: true,
    watchOptions: {
      // 不监听的文件或文件夹，支持正则匹配 意味着node_modules文件变动需要重新运行
      ignored: /node_modules/,
      // 监听到变化后等200ms再去执行动作
      aggregateTimeout: 200,
      // 默认每秒询问1000次
      poll: 1000
    },
    proxy: {
      '/api': {
        target: process.env.VUE_APP_API,
        secure: true,
        changeOrigin: true
      }
    }
  },
  css: {
    loaderOptions: {
      less: {
        // ant-design-vue自定义样式
        lessOptions: {
          modifyVars,
          javascriptEnabled: true
        }
      }
    }
  },
  chainWebpack (config) {
    // ant-design-vue icon 按需打包
    config.resolve.alias
      .set('@ant-design/icons/lib/dist$', path.resolve('src/assets/icons/icons.js'))
    // webpack splitChunks 拆包
    config.optimization.clear('splitChunks').splitChunks({
      cacheGroups: {
        vendors: {
          name: 'chunk-vendors',
          test: /[\\/]node_modules[\\/]/,
          priority: -10,
          chunks: 'initial'
        },
        common: {
          name: 'chunk-common',
          minChunks: 2,
          priority: -20,
          chunks: 'initial',
          reuseExistingChunk: true
        }
      }
    })
    // moment 本地化locale文件仅打包en|zh
    config.plugin('ContextReplacementPlugin').use(webpack.ContextReplacementPlugin, [/moment[/\\]locale$/, /en|zh/])
  },
  configureWebpack () {
    return {
      plugins: [
        // 打包生成gzip格式压缩文件，nginx配置支持gzip
        new CompressionPlugin({
          test: /\.js$|\.html$|\.css/, // 匹配文件名
          threshold: 10240, // 对超过10k的数据压缩
          deleteOriginalAssets: false // true 不删除源文件 false 删除源文件
        }),
        process.env.use_analyzer ? new BundleAnalyzerPlugin({
          analyzerPort: 9999
        }) : null
      ].filter(Boolean)
    }
  }
}
