/*
 * @Description: 模板杂项
 */
module.exports = {
  // npm项目描述
  npm: `
  ▾ src/
    ▾ core/                   // 核心功能
  .babelrc.js
  .eslintrc.js
  .gitignore
  .npmignore
  package-lock.json
  package.json
  README.md
  rollup.config.js
  `,
  // 后台业务项目描述
  busBackEnd: `
  ▸ public/
  ▾ src/
    ▸ api/                    // API
    ▸ assets/                 // 静态资源
    ▸ components/             // 组件目录
    ▸ constants/              // 常量
    ▾ entry/                  // 页面入口
      ▸ admin/                // 后台项目特有
    ▾ layout/                 // 布局
        adminLayout.vue       // 后台项目特有
    ▸ permissions/            // 权限相关，和现有项目一致
    ▾ router/                 // 路由
        admin.js              // 后台项目特有
        index.js
    ▸ setup/
    ▸ store/
    ▸ utils/
    ▾ views/
      ▸ admin/                // 后台项目页面
      ▸ common/               // 403、404
    .browserslistrc
    .DS_Store
    .editorconfig
    .env.dev
    .env.production
    .eslintignore
    .eslintrc.js
    .gitignore
    babel.config.js
    build.sh
    package-lock.json
    package.json
    README.md
    vue.config.js
`,
  // 前台业务项目描述
  busFrontEnd: `
  ▸ public/
  ▾ src/
    ▸ api/                    // API
    ▸ assets/                 // 静态资源
    ▸ components/             // 组件目录
    ▸ constants/              // 常量
    ▾ entry/                  // 页面入口
      ▸ frontEnd/             // 前台项目特有
    ▾ layout/                 // 布局
        frontEndLayout.vue    // 前台项目特有
    ▸ permissions/            // 权限相关，和现有项目一致
    ▾ router/                 // 路由
        front.js              // 前台项目特有
        index.js
    ▸ setup/
    ▸ store/
    ▸ utils/
    ▾ views/
      ▸ common/               // 403、404
      ▸ frontEnd/             // 前台项目页面
    .browserslistrc
    .DS_Store
    .editorconfig
    .env.dev
    .env.production
    .eslintignore
    .eslintrc.js
    .gitignore
    babel.config.js
    build.sh
    package-lock.json
    package.json
    README.md
    vue.config.js
`,
  // 前后台一体项目描述
  busEnd: `
  ▸ public/
  ▾ src/
    ▸ api/                    // API
    ▸ assets/                 // 静态资源
    ▸ components/             // 组件目录
    ▸ constants/              // 常量
    ▾ entry/                  // 页面入口
      ▸ admin/                // 后台项目特有
      ▸ frontEnd/             // 前台项目特有
    ▾ layout/                 // 布局
        adminLayout.vue       // 后台项目特有
        frontEndLayout.vue    // 前台项目特有
    ▸ permissions/            // 权限相关，和现有项目一致
    ▾ router/                 // 路由
        admin.js              // 后台项目特有
        front.js              // 前台项目特有
        index.js
    ▸ setup/
    ▸ store/
    ▸ utils/
    ▾ views/
      ▸ admin/                // 后台项目页面
      ▸ common/               // 403、404
      ▸ frontEnd/             // 前台项目页面
    .browserslistrc
    .DS_Store
    .editorconfig
    .env.dev
    .env.production
    .eslintignore
    .eslintrc.js
    .gitignore
    babel.config.js
    build.sh
    package-lock.json
    package.json
    README.md
    vue.config.js
`
}
