## 安装

```
npm install <%= enName %>
```

## 编译

```
npm run build
```

## 发布

```
npm login

npm publish
```

### 调用 <%= enName %>

```
import npmProjectName from '<%= enName %>'

export default npmProjectName()
```
