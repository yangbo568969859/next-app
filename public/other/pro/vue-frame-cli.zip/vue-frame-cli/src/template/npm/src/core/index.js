export function hello () {
  console.log('npm初始化项目')
}
