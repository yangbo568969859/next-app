import { hello } from './core/index'

// function npmProject() {
//   hello()
// }

export { hello } // es 按需

// export default npmProject // umd
