const fs = require('fs');
const path = require('path');//解析需要遍历的文件夹

/**
 * @description: 文件遍历方法
 * @param String filePath
 * @return Array<String> fileNameList
 */
const iterator = (filePath) => {
  let results = []
  const files = fs.readdirSync(filePath)
  //遍历读取到的文件列表
  files.forEach((filename) => {
    //获取当前文件的绝对路径
    var filedir = path.join(filePath, filename)
    //根据文件路径获取文件信息，返回一个fs.Stats对象
    const stats = fs.statSync(filedir)
    const isFile = stats.isFile();//是文件
    const isDir = stats.isDirectory();//是文件夹
    if(isFile){
      results.push(filedir)
    }
    if(isDir){
      results = results.concat(iterator(filedir));//递归，如果是文件夹，就继续遍历该文件夹下面的文件
    }
  });
  return results
}

module.exports = {
  iterator
}