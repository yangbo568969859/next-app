const chalk = require('chalk')
const figlet = require('figlet')

module.exports = () => {
  const data = figlet.textSync('<  HY - CLI  >')
  console.log(chalk.green(data))
}
