const paramVerify = require('./param')
const log = require('../utils/log')
/**
 * @description: 校验
 */
const Verify = async (options) => {
  log.success('运行校验通过 \n')
  return paramVerify(options)
}

module.exports = Verify