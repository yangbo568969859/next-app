/**
 * @description: 参数校验
 */
const verify = (options) => {
  const pLength = Object.keys(options).length
  if (!pLength) {
    console.error('参数错误，输入hy-cli -h查询使用说明')
    return false
  } else if (pLength > 1) {
    console.error('请勿输入多个指令')
    return false
  }
  return true
}

module.exports = verify