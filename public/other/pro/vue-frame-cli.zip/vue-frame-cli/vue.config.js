/* eslint-disable */
let exportsConfig = {}
exportsConfig.lintOnSave = 'warning'
// if (process.env.NODE_ENV === 'development') {
  exportsConfig.devServer = {
    port: 80, // 端口号
    host: 'test.163yun.com', // 本地开发域名
    // proxy: 'http://localhost:4000' // 配置跨域处理,只有一个代理
    disableHostCheck: true,
    compress: true,
    proxy: {
      '/api': {
        target: process.env.VUE_APP_API,
        secure: true,
        changeOrigin: true
      }
    },
  }
// }
module.exports = exportsConfig
