// _ga=GA1.2.801667098.1709806688; hb_MA-8D32-CBB074308F88_source=docs.popo.netease.com; ehrIsFirstIn=true; _ntes_nnid=ccbcda123b8f0aa7a428d0a97eb9cf3d,1710231014801; mp_versions_hubble_jsSDK=DATracker.globals.1.6.14; mp_MA-AF5D-8C93007541D1_hubble=%7B%22sessionReferrer%22%3A%20%22https%3A%2F%2Ffengchao.youdata.netease.com%2Fdash%2Fshare%2F90419%3Fdid%3D177684%26id%3D2530360%26token%3D17086525721198f6a171bf73ec1c7837db28a%22%2C%22updatedTime%22%3A%201711521432762%2C%22sessionStartTime%22%3A%201711521432764%2C%22sendNumClass%22%3A%20%7B%22allNum%22%3A%202%2C%22errSendNum%22%3A%200%7D%2C%22deviceUdid%22%3A%20%22b7fdcc46dcbafb1a65ca76d736bab1a4fbf6d453%22%2C%22persistedTime%22%3A%201709879980633%2C%22LASTEVENT%22%3A%20%7B%22eventId%22%3A%20%22login%22%2C%22time%22%3A%201711521432765%7D%2C%22currentReferrer%22%3A%20%22https%3A%2F%2Ffengchao.youdata.netease.com%2Fdash%2Fshare%2F90419%3Fdid%3D177684%26id%3D2530360%26token%3D17086525721198f6a171bf73ec1c7837db28a%22%2C%22sessionUuid%22%3A%20%22f8f086cf583ea194c570ae78c9706228cbda60ee%22%2C%22user_id%22%3A%20%22zhuminghua%40corp.netease.com%22%7D; hrs_online_op_state_id_1.0=wdustgrq2x; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2218f5c2687f8a3b-094b5c3758009-26001d51-1474560-18f5c2687f918de%22%2C%22first_id%22%3A%22%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThmNWMyNjg3ZjhhM2ItMDk0YjVjMzc1ODAwOS0yNjAwMWQ1MS0xNDc0NTYwLTE4ZjVjMjY4N2Y5MThkZSJ9%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%22%2C%22value%22%3A%22%22%7D%2C%22%24device_id%22%3A%2218f5c2687f8a3b-094b5c3758009-26001d51-1474560-18f5c2687f918de%22%7D; ntes-km4-canary=false; OPENID_state_id_V1=y7tq38t1vb; returnUrl=https://salon.netease.com/app/course-detail?id=98940&type=salon&tab=course; hb_MA-BC43-D95DB2189621_source=login.netease.com; hb_MA-84C2-1746F3C61AD5_source=e.netease.com; visited_surveyid171824=171818054488112651; answered_surveyid171824=171818054488112651; answered_count_171824=1; answered_count_expire171824=2592000; hb_MA-8391-8FFD554DBEE5_source=office.netease.com; _ga_XVRD1WG0L5=GS1.2.1718351071.89.1.1718351320.0.0.0; hb_MA-8993-0A09EA47275D_source=hz.oa.netease.com; op_state_id_1.0=9tCUwDe0Myt_32EXtHr4rk1kZT9x4l0WKZ6HwaaNA-U; authOpenIdToken=auth:openId:eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJFSFJfSVNTVUVSIiwiZXhwIjoxNzE4NzgwMDAzLCJpYXQiOjE3MTg2OTM2MDMsInVzZXJuYW1lIjoiSDI3Mzk5In0.i8HTt1UcieId2K5ZziwQHV2Byd_o70NJnl8ekxxJxJ4; authOpenIdTokenExpireAt=1718780003000; JSESSIONID=D65D56C37B4DFE633D8FFADE082B7B0C

const https = require('https')
const fs = require('fs')
const path = require('path')
const got = require('got')

const aaa = fs.readFileSync(path.join(process.cwd(), 'question/index.json'), 'utf8')
const realData = JSON.parse(aaa)

let url = 'https://salon.netease.com/api/salon/exam/web/question/detail'
const options = {
  hostname: 'salon.netease.com',
  port: 80,
  path: '/api/salon/exam/web/question/detail',
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
    'Cookie': '_ga=GA1.2.801667098.1709806688; hb_MA-8D32-CBB074308F88_source=docs.popo.netease.com; ehrIsFirstIn=true; _ntes_nnid=ccbcda123b8f0aa7a428d0a97eb9cf3d,1710231014801; mp_versions_hubble_jsSDK=DATracker.globals.1.6.14; mp_MA-AF5D-8C93007541D1_hubble=%7B%22sessionReferrer%22%3A%20%22https%3A%2F%2Ffengchao.youdata.netease.com%2Fdash%2Fshare%2F90419%3Fdid%3D177684%26id%3D2530360%26token%3D17086525721198f6a171bf73ec1c7837db28a%22%2C%22updatedTime%22%3A%201711521432762%2C%22sessionStartTime%22%3A%201711521432764%2C%22sendNumClass%22%3A%20%7B%22allNum%22%3A%202%2C%22errSendNum%22%3A%200%7D%2C%22deviceUdid%22%3A%20%22b7fdcc46dcbafb1a65ca76d736bab1a4fbf6d453%22%2C%22persistedTime%22%3A%201709879980633%2C%22LASTEVENT%22%3A%20%7B%22eventId%22%3A%20%22login%22%2C%22time%22%3A%201711521432765%7D%2C%22currentReferrer%22%3A%20%22https%3A%2F%2Ffengchao.youdata.netease.com%2Fdash%2Fshare%2F90419%3Fdid%3D177684%26id%3D2530360%26token%3D17086525721198f6a171bf73ec1c7837db28a%22%2C%22sessionUuid%22%3A%20%22f8f086cf583ea194c570ae78c9706228cbda60ee%22%2C%22user_id%22%3A%20%22zhuminghua%40corp.netease.com%22%7D; hrs_online_op_state_id_1.0=wdustgrq2x; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2218f5c2687f8a3b-094b5c3758009-26001d51-1474560-18f5c2687f918de%22%2C%22first_id%22%3A%22%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThmNWMyNjg3ZjhhM2ItMDk0YjVjMzc1ODAwOS0yNjAwMWQ1MS0xNDc0NTYwLTE4ZjVjMjY4N2Y5MThkZSJ9%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%22%2C%22value%22%3A%22%22%7D%2C%22%24device_id%22%3A%2218f5c2687f8a3b-094b5c3758009-26001d51-1474560-18f5c2687f918de%22%7D; ntes-km4-canary=false; OPENID_state_id_V1=y7tq38t1vb; returnUrl=https://salon.netease.com/app/course-detail?id=98940&type=salon&tab=course; hb_MA-BC43-D95DB2189621_source=login.netease.com; hb_MA-84C2-1746F3C61AD5_source=e.netease.com; visited_surveyid171824=171818054488112651; answered_surveyid171824=171818054488112651; answered_count_171824=1; answered_count_expire171824=2592000; hb_MA-8391-8FFD554DBEE5_source=office.netease.com; _ga_XVRD1WG0L5=GS1.2.1718351071.89.1.1718351320.0.0.0; hb_MA-8993-0A09EA47275D_source=hz.oa.netease.com; op_state_id_1.0=9tCUwDe0Myt_32EXtHr4rk1kZT9x4l0WKZ6HwaaNA-U; authOpenIdToken=auth:openId:eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJFSFJfSVNTVUVSIiwiZXhwIjoxNzE4NzgwMDAzLCJpYXQiOjE3MTg2OTM2MDMsInVzZXJuYW1lIjoiSDI3Mzk5In0.i8HTt1UcieId2K5ZziwQHV2Byd_o70NJnl8ekxxJxJ4; authOpenIdTokenExpireAt=1718780003000; JSESSIONID=D65D56C37B4DFE633D8FFADE082B7B0C'
  }
};
const answerList = []
const getAnswer = async (data) => {
  const res = await got.get({
    url: `${url}?id=${data}&examScene=PRACTICE`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': '_ga=GA1.2.801667098.1709806688; hb_MA-8D32-CBB074308F88_source=docs.popo.netease.com; ehrIsFirstIn=true; _ntes_nnid=ccbcda123b8f0aa7a428d0a97eb9cf3d,1710231014801; mp_versions_hubble_jsSDK=DATracker.globals.1.6.14; mp_MA-AF5D-8C93007541D1_hubble=%7B%22sessionReferrer%22%3A%20%22https%3A%2F%2Ffengchao.youdata.netease.com%2Fdash%2Fshare%2F90419%3Fdid%3D177684%26id%3D2530360%26token%3D17086525721198f6a171bf73ec1c7837db28a%22%2C%22updatedTime%22%3A%201711521432762%2C%22sessionStartTime%22%3A%201711521432764%2C%22sendNumClass%22%3A%20%7B%22allNum%22%3A%202%2C%22errSendNum%22%3A%200%7D%2C%22deviceUdid%22%3A%20%22b7fdcc46dcbafb1a65ca76d736bab1a4fbf6d453%22%2C%22persistedTime%22%3A%201709879980633%2C%22LASTEVENT%22%3A%20%7B%22eventId%22%3A%20%22login%22%2C%22time%22%3A%201711521432765%7D%2C%22currentReferrer%22%3A%20%22https%3A%2F%2Ffengchao.youdata.netease.com%2Fdash%2Fshare%2F90419%3Fdid%3D177684%26id%3D2530360%26token%3D17086525721198f6a171bf73ec1c7837db28a%22%2C%22sessionUuid%22%3A%20%22f8f086cf583ea194c570ae78c9706228cbda60ee%22%2C%22user_id%22%3A%20%22zhuminghua%40corp.netease.com%22%7D; hrs_online_op_state_id_1.0=wdustgrq2x; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2218f5c2687f8a3b-094b5c3758009-26001d51-1474560-18f5c2687f918de%22%2C%22first_id%22%3A%22%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThmNWMyNjg3ZjhhM2ItMDk0YjVjMzc1ODAwOS0yNjAwMWQ1MS0xNDc0NTYwLTE4ZjVjMjY4N2Y5MThkZSJ9%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%22%2C%22value%22%3A%22%22%7D%2C%22%24device_id%22%3A%2218f5c2687f8a3b-094b5c3758009-26001d51-1474560-18f5c2687f918de%22%7D; OPENID_state_id_V1=y7tq38t1vb; returnUrl=https://salon.netease.com/app/course-detail?id=98940&type=salon&tab=course; hb_MA-BC43-D95DB2189621_source=login.netease.com; visited_surveyid171824=171818054488112651; answered_surveyid171824=171818054488112651; answered_count_171824=1; answered_count_expire171824=2592000; hb_MA-8391-8FFD554DBEE5_source=office.netease.com; _ga_XVRD1WG0L5=GS1.2.1718351071.89.1.1718351320.0.0.0; hb_MA-8993-0A09EA47275D_source=hz.oa.netease.com; JSESSIONID=D65D56C37B4DFE633D8FFADE082B7B0C; ntes-km4-canary=false; _km_noosfero_session=eyJpZGVudGlmaWVyIjoieWFuZ2JvMDgiLCJwcm9maWxlIjo3NTk3MSwidXNlciI6Nzk0NTd9--ce323514ed97a209a835ba5fc30b26b5c8ca0fff; ntes-km4-session=c6ddcc68-ac47-4fa5-b881-0a85c7c7dd5f; hb_MA-9CCF-FA0F3FF11301_source=login.netease.com; _kms_session=eyJpZGVudGlmaWVyIjoieWFuZ2JvMDgiLCJzZXNzaW9uX2lkIjoiZGE2MTg0YjQ3ZDAzMjJkMmZhOGZmOTEwY2I1YThkODIiLCJ1c2VyIjo5NDEwNCwicHJvZmlsZSI6OTQ2ODgsInByb2ZpbGUiOjk0Njg4LCJpZGVudGlmaWVyIjoieWFuZ2JvMDgifQ%3D%3D--1d83c790380b7a830e6cfaee271418fcd9a3a46b; hb_MA-84C2-1746F3C61AD5_source=kms.netease.com; returnUrl=https://salon.netease.com/inner-exam/theory?direction=ALGORITHM; errUrl=https://salon.netease.com/inner-exam/theory?direction=ALGORITHM; op_state_id_1.0=nuKN8x-2qsYG86w8qWCluXDatEqDvSlnQ0N2-rl9aSA; authOpenIdToken=auth:openId:eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJFSFJfSVNTVUVSIiwiZXhwIjoxNzE5NjI4Nzk2LCJpYXQiOjE3MTk1NDIzOTYsInVzZXJuYW1lIjoiSDI3Mzk5In0.ojlYz3r-pld6c3PdrWkkAXqw638Z-1I1o7BD483X90g; authOpenIdTokenExpireAt=1719628796000'
    }
  })
  const resdata = JSON.parse(res.body)
  answerList.push(resdata.data)
}
let count = realData.data.length;
let startCount = 0;
async function dealAns () {
  console.log(count);
  // await getAnswer(351)
  for (let i = 0; i < count; i++) {
    await getAnswer(realData.data[i].id)
  }
  writeFileToQues();
}

function writeFileToQues () {
  fs.writeFileSync(
    path.join(process.cwd(), 'question/c++.json'),
    JSON.stringify(answerList)
  );
}

dealAns()

// https://salon.netease.com/api/salon/exam/web/question/detail?id=2029&examScene=PRACTICE

